package com.gaowenyun.gift.model.bean;

import java.util.List;

/**
 *
 */
public class SelecitonLvDetailBean {
    /**
     * code : 200
     * data : {"ad_monitors":null,"column":{"banner_image_url":"http://img02.liwushuo.com/image/160902/rnyu3ltr7.jpg-w300","category":"涨姿势","cover_image_url":"http://img02.liwushuo.com/image/160902/ompte4huy.jpg-w720","created_at":1472812600,"description":"从搭讪到追求到恋爱到分手，一条龙全套大保健，从头教到尾","id":103,"order":0,"post_published_at":1474070400,"status":0,"subtitle":"","title":"撩妹学院","updated_at":1474452340},"column_bottom":null,"column_header":null,"comments_count":4,"content":null,"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045728/content","cover_image_url":"http://img02.liwushuo.com/image/160912/7bp8g3itz.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160912/7bp8g3itz.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1474106460,"editor_id":1114,"feature_list":[],"id":1045728,"introduction":"连表白都不敢，就没谈恋爱了吧","item_ad_monitors":{},"label_ids":[],"liked":false,"likes_count":1971,"limit_end_at":null,"published_at":1474070400,"share_msg":"分享自@礼物说\u2014送礼物就上礼物说","shares_count":168,"short_title":"","status":0,"template":"","title":"撩妹学院第三课：表白就是奏响胜利的凯歌","updated_at":1474108522,"url":"http://hawaii.liwushuo.com/posts/1045728","content_html":"<!DOCTYPE html><html lang=zh-CN id=liwushuo prefix=\"og: http://ogp.me/ns#\"><head><meta charset=utf-8><title>  <\/title><meta http-equiv=X-UA-Compatible content=\"IE=edge,chrome=1\"><meta http-equiv=Content-Language content=zh_CN><link rel=canonical href=\"http://www.liwushuo.com/\"><meta name=viewport content=\"width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0\"><meta name=keywords content=礼物说,全球好货,会说话的礼物,会说话,条形码,扫描条形码,扫码留声,扫条码存声音,让礼物开口说话,二维码扫描,二维码制作,移动二维码,创意二维码><meta name=description content=\"礼物说，一个帮你选【全球好货】的 App，带你逛遍全世界的好东西，送出感动ta的礼物。安卓,iOS版本均可在应用商店下载。\"><meta name=apple-mobile-web-app-capable content=yes><meta name=apple-mobile-web-app-status-bar-style content=black><meta name=format-detection content=\"telephone=no\"><meta name=copyright content=\"© 2014 - 2016 Liwushuo.com 北京礼品说科技有限公司\"><meta property=og:url content=http://www.liwushuo.com><meta property=og:site_name content=礼物说－礼物和全球好货指南><meta property=og:title content=礼物说－礼物和全球好货指南><meta property=og:type content=website><meta property=og:locale content=zh_CN><link rel=apple-touch-icon sizes=57x57 href=http://static.liwushuo.com/static/web/img/favicon/apple-icon-57x57_10d74da.png><link rel=apple-touch-icon sizes=76x76 href=http://static.liwushuo.com/static/web/img/favicon/apple-icon-76x76_c08081d.png><link rel=apple-touch-icon sizes=120x120 href=http://static.liwushuo.com/static/web/img/favicon/apple-icon-120x120_3317fa3.png><link rel=apple-touch-icon sizes=152x152 href=http://static.liwushuo.com/static/web/img/favicon/apple-icon-152x152_5fde678.png><link rel=icon type=image/png sizes=32x32 href=http://static.liwushuo.com/static/web/img/favicon/favicon-32x32_23d4a98.png><link rel=icon type=image/png sizes=96x96 href=http://static.liwushuo.com/static/web/img/favicon/favicon-96x96_acf6191.png><meta name=msapplication-TileImage content=/web/style/img/favicon/ms-icon-144x144.png><link rel=\"shortcut icon\" href=\"http://7xveoj.com2.z0.glb.qiniucdn.com/favicon.ico\" type=image/x-icon><link rel=\"Shortcut Icon\" href=http://static.liwushuo.com/static/web/img/favicon/favicon_23d4a98.png><link rel=Bookmark href=http://static.liwushuo.com/static/web/img/favicon/favicon_23d4a98.png> <link rel=stylesheet href=\"http://7xveoj.com2.z0.glb.qiniucdn.com/static/layouts/layout-9b0b185ef5.css\"><script src=\"http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/require/require.js\"><\/script><script>\n  require.config({\n    baseUrl: 'http://7xveoj.com2.z0.glb.qiniucdn.com/static',\n    paths: {\n      'lib': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components',\n      'jquery': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/jquery/dist/jquery.min',\n      'swiper': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/swiper/dist/js/swiper.min',\n      'gift': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/gift/dist/gift.min',\n      'jtap': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/jtap/jquery.tap',\n      'jweixin': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/jweixin/jweixin-1.0.0',\n      'wxshare': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/wxshare/wxshare',\n      'echo': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/echojs/dist/echo.min',\n      'howler': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/howlerjs/dist/howler.core.min',\n\n    },\n    shim: {\n      'jtap': ['jquery']\n    }\n  });\n\n  var _config = {};\n\n  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){\n    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\n    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\n  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');\n  \n  ga('create', 'UA-50837091-2', 'www.liwushuo.com');\n  ga('send', 'pageview');\n\n  var _hmt = _hmt || [];\n  (function() {\n    var hm = document.createElement(\"script\");\n    hm.src = \"//hm.baidu.com/hm.js?8a996f7888dea2ea6d5611cd24318338\";\n    var s = document.getElementsByTagName(\"script\")[0];\n    s.parentNode.insertBefore(hm, s);\n  })();\n\n  var adjustPaddingTop = window.adjustPaddingTop = function (v) { \n    document.getElementById('body').style.paddingTop = (v + 'px'); \n  };\n\n  document.addEventListener(\"DOMContentLoaded\", function(event) {\n    location.href = \"liwushuo:///notify?name=domloadfinish\";\n  });\n  <\/script><link rel=stylesheet href=\"http://7xveoj.com2.z0.glb.qiniucdn.com/static/post_content/post_content-6e8b012f0f.css\"><\/head><body id=body data-feature={\"is_support_swiper\":true,\"deprecated\":true,\"hide_top_image\":true,\"is_alipay_webview\":false,\"is_shown_post_title\":true,\"WEB_API_ENDPOINT\":\"http://hawaii.liwushuo.com\"}><div id=main> <div id=post_content class=\"post_content post\" data-post-id=\"1045728\"><h1 class=post-title>撩妹学院第三课：表白就是奏响胜利的凯歌<\/h1>  <style>\n  @import 'http://7xveoj.com2.z0.glb.qiniucdn.com/static/components/content/content-9cdf91e8a3.css';\n<\/style><div id=content class=content> <p style=\"text-align: center;\"><img src=\"http://img01.liwushuo.com/image/160912/mi5q7p7d9.gif\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img01.liwushuo.com/image/160912/mi5q7p7d9.gif&quot;,&quot;width&quot;:640,&quot;height&quot;:340}\">搭讪是认识女生的敲门砖，<\/p>\r\n<p style=\"text-align: center;\">聊天是勘探彼此的入场券，<\/p>\r\n<p style=\"text-align: center;\">约会是发起进攻的冲锋号，&nbsp;<\/p>\r\n<p style=\"text-align: center;\">那<span style=\"color: #f84e4e;\"><strong>表白，就是奏响胜利的凯歌<\/strong><\/span>。<\/p>\r\n<p>&nbsp;<\/p>\r\n<p>表白是个顺理成章自然而然的过程，而不是为了表白而表白。如果你感觉表白后有被拒的可能，那你真是大可不必开口。除非你是抱着试一试的态度，那强行表白的结果很可能就是白表，你们连朋友都做不了。<\/p>\r\n<p>&nbsp;<\/p>\r\n<h2 class=\"section-title\">那什么时候才应该表白呢？<\/h2>\r\n<p>&nbsp;<\/p>\r\n<p><img src=\"http://img02.liwushuo.com/image/160912/7xffbvo6r.gif\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img02.liwushuo.com/image/160912/7xffbvo6r.gif&quot;,&quot;width&quot;:640,&quot;height&quot;:334}\">首先你们<span style=\"color: #f84e4e;\"><strong>已经聊了很多个夜晚<\/strong><\/span>，聊到夜不能寐、聊到辗转反侧、聊到到了非要把积存心里的爱意向对方表达的程度；<\/p>\r\n<p>&nbsp;<\/p>\r\n<p>其次你们<span style=\"color: #f84e4e;\"><strong>不仅仅停留于网络交流<\/strong><\/span>，在线下也面对面聊过天，吃过几顿饭、看过几场电影、逛过几次街，相处不尴尬、彼此不排斥；<\/p>\r\n<p>&nbsp;<\/p>\r\n<p>然后在某些敏感的<span style=\"color: #f84e4e;\"><strong>问题上都能取得一致的意见<\/strong><\/span>。例如：年龄、性格、职业、爱好和志向、姿势等方面；<\/p>\r\n<p>&nbsp;<\/p>\r\n<p>最后<span style=\"color: #f84e4e;\"><strong>挑一个对方情绪稳定、高涨的时候<\/strong><\/span>。因为这时对方正对爱情和幸福充满渴望和追求，是易接受求爱的最佳时机。比如某个电影散场的夜晚，比较某个浪漫微醺的酒后。<\/p>\r\n<p>&nbsp;<\/p>\r\n<h2 class=\"section-title\">表白时说些什么呢？<\/h2>\r\n<p>&nbsp;<\/p>\r\n<p><img src=\"http://img02.liwushuo.com/image/160912/r56zww0y5.jpg-w720\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img02.liwushuo.com/image/160912/r56zww0y5.jpg-w720&quot;,&quot;width&quot;:640,&quot;height&quot;:278}\">王家卫有次让演员翻译I love you，有的演员直接说\u201c我爱你\u201d 诗人王说：怎么可以说出这样的话，应该是\u201c我已经很久没有坐过摩托车了，也很久没有试过这么接近一个人了，虽然我知道这条路不是很远，虽然我知道不久我就会下车。可是，这一分钟，我觉得很暖。\u201d<\/p>\r\n<p>&nbsp;<\/p>\r\n<p>据说女生最容易产生情意的时候就是男生说出动人情话时。女生对听觉的刺激通常比较敏感，一般亲切温柔动情的话语更能打动女生。普普通通的表白自然没什么问题，可是稍微有点特色，也许女生对你的痴迷会更深。<\/p>\r\n<p>&nbsp;<\/p>\r\n<p><span style=\"color: #f84e4e;\"><strong>比如来点古诗词<\/strong><\/span>：情不知所起，一往而深，生者可以死，死者可以生；<\/p>\r\n<p><span style=\"color: #f84e4e;\"><strong>比如来点歌词<\/strong><\/span>：最美的不是下雨天，而是和你一起躲过的屋檐；<\/p>\r\n<p><span style=\"color: #f84e4e;\"><strong>比如来点台词<\/strong><\/span>：以后给孩子取名就叫不悔，爱你这件事永远不会后悔；<\/p>\r\n<p>再比如，<span style=\"color: #f84e4e;\"><strong>来点经典文章<\/strong><\/span>：我想和你困觉。&nbsp;<\/p>\r\n<p>&nbsp;<\/p>\r\n<h2 class=\"section-title\">有哪些创意的表白方式呢？<\/h2>\r\n<p>&nbsp;<\/p>\r\n<p>除了面对面直接说，来点新奇的创意表白，能让女生在感动的同时多一份惊喜，这样成功的几率也会随之上升。<\/p>\r\n<p>&nbsp;<\/p>\r\n<p>如果你追的姑娘喜欢化学：<img src=\"http://img01.liwushuo.com/image/160912/ujjpa8mut.jpeg-w720\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img01.liwushuo.com/image/160912/ujjpa8mut.jpeg-w720&quot;,&quot;width&quot;:422,&quot;height&quot;:159}\"><\/p>\r\n<p>如果你追的姑娘喜欢数学：<img src=\"http://img03.liwushuo.com/image/160912/jb50gb50r.png-w720\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img03.liwushuo.com/image/160912/jb50gb50r.png-w720&quot;,&quot;width&quot;:467,&quot;height&quot;:452}\"><\/p>\r\n<p>如果你追的姑娘喜欢甜食：<img src=\"http://img03.liwushuo.com/image/160912/56hcbcu6o.jpg-w720\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img03.liwushuo.com/image/160912/56hcbcu6o.jpg-w720&quot;,&quot;width&quot;:700,&quot;height&quot;:507}\"><\/p>\r\n<p>如果你追的姑娘喜欢音乐：<img src=\"http://img01.liwushuo.com/image/160912/rr8m7pvzw.png-w720\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img01.liwushuo.com/image/160912/rr8m7pvzw.png-w720&quot;,&quot;width&quot;:288,&quot;height&quot;:243}\"><\/p>\r\n<p>如果你追的姑娘喜欢可乐：<img src=\"http://img01.liwushuo.com/image/160912/az8bmepu1.png-w720\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img01.liwushuo.com/image/160912/az8bmepu1.png-w720&quot;,&quot;width&quot;:486,&quot;height&quot;:273}\"><\/p>\r\n<p>或者直接上绝活：<\/p>\r\n<p style=\"text-align: left;\"><img src=\"http://img02.liwushuo.com/image/160912/z4ecov3ms.jpg-w720\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img02.liwushuo.com/image/160912/z4ecov3ms.jpg-w720&quot;,&quot;width&quot;:409,&quot;height&quot;:319}\"><br><img src=\"http://img02.liwushuo.com/image/160912/brpdd9i9p.png-w720\" alt=\"\" data-payload=\"{&quot;url&quot;:&quot;http://img02.liwushuo.com/image/160912/brpdd9i9p.png-w720&quot;,&quot;width&quot;:411,&quot;height&quot;:414}\"><br>表白时，眼神一定要温柔深情看着对方，语气一定要真诚真挚打动对方。千万别怂，反正无非两个结果：<\/p>\r\n<p style=\"text-align: center;\"><span style=\"color: #f84e4e;\"><strong>行，就行；<\/strong><\/span><br><span style=\"color: #f84e4e;\"><strong>不行，我再想想办法。<\/strong><\/span><\/p>\r\n<p style=\"text-align: center;\">&nbsp;小伙子，为了中华崛起而奋斗吧。<\/p>\r\n<p>&nbsp;<\/p> <\/div>  <script>\n  require(['components/content/content-4d5484b872']);\n<\/script> <\/div><style>\n  @import 'http://7xveoj.com2.z0.glb.qiniucdn.com/static/components/recommend/recommend-8cb9e85dbf.css';\n<\/style><div id=recommend class=\"recommond-container recommend\"><div class=cross><span class=cross-line><\/span> <span class=cross-text>你可能也喜欢<\/span><\/div><div id=postList scroll=no><\/div><div class=hide-scroll-bar><\/div><\/div> <script>\n  require(['components/recommend/recommend-54fc8552ee']);\n<\/script>   <script>\n      require(['layouts/layout-045d5c66ef']);\n    <\/script><script>\n  require(['post_content/post_content-0f877afe99']);\n<\/script><\/div><\/body><\/html>"}
     * message : OK
     */

    private int code;
    /**
     * ad_monitors : null
     * column : {"banner_image_url":"http://img02.liwushuo.com/image/160902/rnyu3ltr7.jpg-w300","category":"涨姿势","cover_image_url":"http://img02.liwushuo.com/image/160902/ompte4huy.jpg-w720","created_at":1472812600,"description":"从搭讪到追求到恋爱到分手，一条龙全套大保健，从头教到尾","id":103,"order":0,"post_published_at":1474070400,"status":0,"subtitle":"","title":"撩妹学院","updated_at":1474452340}
     * column_bottom : null
     * column_header : null
     * comments_count : 4
     * content : null
     * content_type : 1
     * content_url : http://www.liwushuo.com/posts/1045728/content
     * cover_image_url : http://img02.liwushuo.com/image/160912/7bp8g3itz.jpg-w720
     * cover_webp_url : http://img02.liwushuo.com/image/160912/7bp8g3itz.jpg?imageView2/2/w/720/q/85/format/webp
     * created_at : 1474106460
     * editor_id : 1114
     * feature_list : []
     * id : 1045728
     * introduction : 连表白都不敢，就没谈恋爱了吧
     * item_ad_monitors : {}
     * label_ids : []
     * liked : false
     * likes_count : 1971
     * limit_end_at : null
     * published_at : 1474070400
     * share_msg : 分享自@礼物说—送礼物就上礼物说
     * shares_count : 168
     * short_title :
     * status : 0
     * template :
     * title : 撩妹学院第三课：表白就是奏响胜利的凯歌
     * updated_at : 1474108522
     * url : http://hawaii.liwushuo.com/posts/1045728
     * content_html : <!DOCTYPE html><html lang=zh-CN id=liwushuo prefix="og: http://ogp.me/ns#"><head><meta charset=utf-8><title>  </title><meta http-equiv=X-UA-Compatible content="IE=edge,chrome=1"><meta http-equiv=Content-Language content=zh_CN><link rel=canonical href="http://www.liwushuo.com/"><meta name=viewport content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0"><meta name=keywords content=礼物说,全球好货,会说话的礼物,会说话,条形码,扫描条形码,扫码留声,扫条码存声音,让礼物开口说话,二维码扫描,二维码制作,移动二维码,创意二维码><meta name=description content="礼物说，一个帮你选【全球好货】的 App，带你逛遍全世界的好东西，送出感动ta的礼物。安卓,iOS版本均可在应用商店下载。"><meta name=apple-mobile-web-app-capable content=yes><meta name=apple-mobile-web-app-status-bar-style content=black><meta name=format-detection content="telephone=no"><meta name=copyright content="© 2014 - 2016 Liwushuo.com 北京礼品说科技有限公司"><meta property=og:url content=http://www.liwushuo.com><meta property=og:site_name content=礼物说－礼物和全球好货指南><meta property=og:title content=礼物说－礼物和全球好货指南><meta property=og:type content=website><meta property=og:locale content=zh_CN><link rel=apple-touch-icon sizes=57x57 href=http://static.liwushuo.com/static/web/img/favicon/apple-icon-57x57_10d74da.png><link rel=apple-touch-icon sizes=76x76 href=http://static.liwushuo.com/static/web/img/favicon/apple-icon-76x76_c08081d.png><link rel=apple-touch-icon sizes=120x120 href=http://static.liwushuo.com/static/web/img/favicon/apple-icon-120x120_3317fa3.png><link rel=apple-touch-icon sizes=152x152 href=http://static.liwushuo.com/static/web/img/favicon/apple-icon-152x152_5fde678.png><link rel=icon type=image/png sizes=32x32 href=http://static.liwushuo.com/static/web/img/favicon/favicon-32x32_23d4a98.png><link rel=icon type=image/png sizes=96x96 href=http://static.liwushuo.com/static/web/img/favicon/favicon-96x96_acf6191.png><meta name=msapplication-TileImage content=/web/style/img/favicon/ms-icon-144x144.png><link rel="shortcut icon" href="http://7xveoj.com2.z0.glb.qiniucdn.com/favicon.ico" type=image/x-icon><link rel="Shortcut Icon" href=http://static.liwushuo.com/static/web/img/favicon/favicon_23d4a98.png><link rel=Bookmark href=http://static.liwushuo.com/static/web/img/favicon/favicon_23d4a98.png> <link rel=stylesheet href="http://7xveoj.com2.z0.glb.qiniucdn.com/static/layouts/layout-9b0b185ef5.css"><script src="http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/require/require.js"></script><script>
     require.config({
     baseUrl: 'http://7xveoj.com2.z0.glb.qiniucdn.com/static',
     paths: {
     'lib': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components',
     'jquery': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/jquery/dist/jquery.min',
     'swiper': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/swiper/dist/js/swiper.min',
     'gift': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/gift/dist/gift.min',
     'jtap': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/jtap/jquery.tap',
     'jweixin': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/jweixin/jweixin-1.0.0',
     'wxshare': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/wxshare/wxshare',
     'echo': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/echojs/dist/echo.min',
     'howler': 'http://7xveoj.com2.z0.glb.qiniucdn.com/bower_components/howlerjs/dist/howler.core.min',

     },
     shim: {
     'jtap': ['jquery']
     }
     });

     var _config = {};

     (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
     (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
     m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
     })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

     ga('create', 'UA-50837091-2', 'www.liwushuo.com');
     ga('send', 'pageview');

     var _hmt = _hmt || [];
     (function() {
     var hm = document.createElement("script");
     hm.src = "//hm.baidu.com/hm.js?8a996f7888dea2ea6d5611cd24318338";
     var s = document.getElementsByTagName("script")[0];
     s.parentNode.insertBefore(hm, s);
     })();

     var adjustPaddingTop = window.adjustPaddingTop = function (v) {
     document.getElementById('body').style.paddingTop = (v + 'px');
     };

     document.addEventListener("DOMContentLoaded", function(event) {
     location.href = "liwushuo:///notify?name=domloadfinish";
     });
     </script><link rel=stylesheet href="http://7xveoj.com2.z0.glb.qiniucdn.com/static/post_content/post_content-6e8b012f0f.css"></head><body id=body data-feature={"is_support_swiper":true,"deprecated":true,"hide_top_image":true,"is_alipay_webview":false,"is_shown_post_title":true,"WEB_API_ENDPOINT":"http://hawaii.liwushuo.com"}><div id=main> <div id=post_content class="post_content post" data-post-id="1045728"><h1 class=post-title>撩妹学院第三课：表白就是奏响胜利的凯歌</h1>  <style>
     @import 'http://7xveoj.com2.z0.glb.qiniucdn.com/static/components/content/content-9cdf91e8a3.css';
     </style><div id=content class=content> <p style="text-align: center;"><img src="http://img01.liwushuo.com/image/160912/mi5q7p7d9.gif" alt="" data-payload="{&quot;url&quot;:&quot;http://img01.liwushuo.com/image/160912/mi5q7p7d9.gif&quot;,&quot;width&quot;:640,&quot;height&quot;:340}">搭讪是认识女生的敲门砖，</p>
     <p style="text-align: center;">聊天是勘探彼此的入场券，</p>
     <p style="text-align: center;">约会是发起进攻的冲锋号，&nbsp;</p>
     <p style="text-align: center;">那<span style="color: #f84e4e;"><strong>表白，就是奏响胜利的凯歌</strong></span>。</p>
     <p>&nbsp;</p>
     <p>表白是个顺理成章自然而然的过程，而不是为了表白而表白。如果你感觉表白后有被拒的可能，那你真是大可不必开口。除非你是抱着试一试的态度，那强行表白的结果很可能就是白表，你们连朋友都做不了。</p>
     <p>&nbsp;</p>
     <h2 class="section-title">那什么时候才应该表白呢？</h2>
     <p>&nbsp;</p>
     <p><img src="http://img02.liwushuo.com/image/160912/7xffbvo6r.gif" alt="" data-payload="{&quot;url&quot;:&quot;http://img02.liwushuo.com/image/160912/7xffbvo6r.gif&quot;,&quot;width&quot;:640,&quot;height&quot;:334}">首先你们<span style="color: #f84e4e;"><strong>已经聊了很多个夜晚</strong></span>，聊到夜不能寐、聊到辗转反侧、聊到到了非要把积存心里的爱意向对方表达的程度；</p>
     <p>&nbsp;</p>
     <p>其次你们<span style="color: #f84e4e;"><strong>不仅仅停留于网络交流</strong></span>，在线下也面对面聊过天，吃过几顿饭、看过几场电影、逛过几次街，相处不尴尬、彼此不排斥；</p>
     <p>&nbsp;</p>
     <p>然后在某些敏感的<span style="color: #f84e4e;"><strong>问题上都能取得一致的意见</strong></span>。例如：年龄、性格、职业、爱好和志向、姿势等方面；</p>
     <p>&nbsp;</p>
     <p>最后<span style="color: #f84e4e;"><strong>挑一个对方情绪稳定、高涨的时候</strong></span>。因为这时对方正对爱情和幸福充满渴望和追求，是易接受求爱的最佳时机。比如某个电影散场的夜晚，比较某个浪漫微醺的酒后。</p>
     <p>&nbsp;</p>
     <h2 class="section-title">表白时说些什么呢？</h2>
     <p>&nbsp;</p>
     <p><img src="http://img02.liwushuo.com/image/160912/r56zww0y5.jpg-w720" alt="" data-payload="{&quot;url&quot;:&quot;http://img02.liwushuo.com/image/160912/r56zww0y5.jpg-w720&quot;,&quot;width&quot;:640,&quot;height&quot;:278}">王家卫有次让演员翻译I love you，有的演员直接说“我爱你” 诗人王说：怎么可以说出这样的话，应该是“我已经很久没有坐过摩托车了，也很久没有试过这么接近一个人了，虽然我知道这条路不是很远，虽然我知道不久我就会下车。可是，这一分钟，我觉得很暖。”</p>
     <p>&nbsp;</p>
     <p>据说女生最容易产生情意的时候就是男生说出动人情话时。女生对听觉的刺激通常比较敏感，一般亲切温柔动情的话语更能打动女生。普普通通的表白自然没什么问题，可是稍微有点特色，也许女生对你的痴迷会更深。</p>
     <p>&nbsp;</p>
     <p><span style="color: #f84e4e;"><strong>比如来点古诗词</strong></span>：情不知所起，一往而深，生者可以死，死者可以生；</p>
     <p><span style="color: #f84e4e;"><strong>比如来点歌词</strong></span>：最美的不是下雨天，而是和你一起躲过的屋檐；</p>
     <p><span style="color: #f84e4e;"><strong>比如来点台词</strong></span>：以后给孩子取名就叫不悔，爱你这件事永远不会后悔；</p>
     <p>再比如，<span style="color: #f84e4e;"><strong>来点经典文章</strong></span>：我想和你困觉。&nbsp;</p>
     <p>&nbsp;</p>
     <h2 class="section-title">有哪些创意的表白方式呢？</h2>
     <p>&nbsp;</p>
     <p>除了面对面直接说，来点新奇的创意表白，能让女生在感动的同时多一份惊喜，这样成功的几率也会随之上升。</p>
     <p>&nbsp;</p>
     <p>如果你追的姑娘喜欢化学：<img src="http://img01.liwushuo.com/image/160912/ujjpa8mut.jpeg-w720" alt="" data-payload="{&quot;url&quot;:&quot;http://img01.liwushuo.com/image/160912/ujjpa8mut.jpeg-w720&quot;,&quot;width&quot;:422,&quot;height&quot;:159}"></p>
     <p>如果你追的姑娘喜欢数学：<img src="http://img03.liwushuo.com/image/160912/jb50gb50r.png-w720" alt="" data-payload="{&quot;url&quot;:&quot;http://img03.liwushuo.com/image/160912/jb50gb50r.png-w720&quot;,&quot;width&quot;:467,&quot;height&quot;:452}"></p>
     <p>如果你追的姑娘喜欢甜食：<img src="http://img03.liwushuo.com/image/160912/56hcbcu6o.jpg-w720" alt="" data-payload="{&quot;url&quot;:&quot;http://img03.liwushuo.com/image/160912/56hcbcu6o.jpg-w720&quot;,&quot;width&quot;:700,&quot;height&quot;:507}"></p>
     <p>如果你追的姑娘喜欢音乐：<img src="http://img01.liwushuo.com/image/160912/rr8m7pvzw.png-w720" alt="" data-payload="{&quot;url&quot;:&quot;http://img01.liwushuo.com/image/160912/rr8m7pvzw.png-w720&quot;,&quot;width&quot;:288,&quot;height&quot;:243}"></p>
     <p>如果你追的姑娘喜欢可乐：<img src="http://img01.liwushuo.com/image/160912/az8bmepu1.png-w720" alt="" data-payload="{&quot;url&quot;:&quot;http://img01.liwushuo.com/image/160912/az8bmepu1.png-w720&quot;,&quot;width&quot;:486,&quot;height&quot;:273}"></p>
     <p>或者直接上绝活：</p>
     <p style="text-align: left;"><img src="http://img02.liwushuo.com/image/160912/z4ecov3ms.jpg-w720" alt="" data-payload="{&quot;url&quot;:&quot;http://img02.liwushuo.com/image/160912/z4ecov3ms.jpg-w720&quot;,&quot;width&quot;:409,&quot;height&quot;:319}"><br><img src="http://img02.liwushuo.com/image/160912/brpdd9i9p.png-w720" alt="" data-payload="{&quot;url&quot;:&quot;http://img02.liwushuo.com/image/160912/brpdd9i9p.png-w720&quot;,&quot;width&quot;:411,&quot;height&quot;:414}"><br>表白时，眼神一定要温柔深情看着对方，语气一定要真诚真挚打动对方。千万别怂，反正无非两个结果：</p>
     <p style="text-align: center;"><span style="color: #f84e4e;"><strong>行，就行；</strong></span><br><span style="color: #f84e4e;"><strong>不行，我再想想办法。</strong></span></p>
     <p style="text-align: center;">&nbsp;小伙子，为了中华崛起而奋斗吧。</p>
     <p>&nbsp;</p> </div>  <script>
     require(['components/content/content-4d5484b872']);
     </script> </div><style>
     @import 'http://7xveoj.com2.z0.glb.qiniucdn.com/static/components/recommend/recommend-8cb9e85dbf.css';
     </style><div id=recommend class="recommond-container recommend"><div class=cross><span class=cross-line></span> <span class=cross-text>你可能也喜欢</span></div><div id=postList scroll=no></div><div class=hide-scroll-bar></div></div> <script>
     require(['components/recommend/recommend-54fc8552ee']);
     </script>   <script>
     require(['layouts/layout-045d5c66ef']);
     </script><script>
     require(['post_content/post_content-0f877afe99']);
     </script></div></body></html>
     */

    private DataBean data;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class DataBean {
        private Object ad_monitors;
        /**
         * banner_image_url : http://img02.liwushuo.com/image/160902/rnyu3ltr7.jpg-w300
         * category : 涨姿势
         * cover_image_url : http://img02.liwushuo.com/image/160902/ompte4huy.jpg-w720
         * created_at : 1472812600
         * description : 从搭讪到追求到恋爱到分手，一条龙全套大保健，从头教到尾
         * id : 103
         * order : 0
         * post_published_at : 1474070400
         * status : 0
         * subtitle :
         * title : 撩妹学院
         * updated_at : 1474452340
         */

        private ColumnBean column;
        private Object column_bottom;
        private Object column_header;
        private int comments_count;
        private Object content;
        private int content_type;
        private String content_url;
        private String cover_image_url;
        private String cover_webp_url;
        private int created_at;
        private int editor_id;
        private int id;
        private String introduction;
        private ItemAdMonitorsBean item_ad_monitors;
        private boolean liked;
        private int likes_count;
        private Object limit_end_at;
        private int published_at;
        private String share_msg;
        private int shares_count;
        private String short_title;
        private int status;
        private String template;
        private String title;
        private int updated_at;
        private String url;
        private String content_html;
        private List<?> feature_list;
        private List<?> label_ids;

        public Object getAd_monitors() {
            return ad_monitors;
        }

        public void setAd_monitors(Object ad_monitors) {
            this.ad_monitors = ad_monitors;
        }

        public ColumnBean getColumn() {
            return column;
        }

        public void setColumn(ColumnBean column) {
            this.column = column;
        }

        public Object getColumn_bottom() {
            return column_bottom;
        }

        public void setColumn_bottom(Object column_bottom) {
            this.column_bottom = column_bottom;
        }

        public Object getColumn_header() {
            return column_header;
        }

        public void setColumn_header(Object column_header) {
            this.column_header = column_header;
        }

        public int getComments_count() {
            return comments_count;
        }

        public void setComments_count(int comments_count) {
            this.comments_count = comments_count;
        }

        public Object getContent() {
            return content;
        }

        public void setContent(Object content) {
            this.content = content;
        }

        public int getContent_type() {
            return content_type;
        }

        public void setContent_type(int content_type) {
            this.content_type = content_type;
        }

        public String getContent_url() {
            return content_url;
        }

        public void setContent_url(String content_url) {
            this.content_url = content_url;
        }

        public String getCover_image_url() {
            return cover_image_url;
        }

        public void setCover_image_url(String cover_image_url) {
            this.cover_image_url = cover_image_url;
        }

        public String getCover_webp_url() {
            return cover_webp_url;
        }

        public void setCover_webp_url(String cover_webp_url) {
            this.cover_webp_url = cover_webp_url;
        }

        public int getCreated_at() {
            return created_at;
        }

        public void setCreated_at(int created_at) {
            this.created_at = created_at;
        }

        public int getEditor_id() {
            return editor_id;
        }

        public void setEditor_id(int editor_id) {
            this.editor_id = editor_id;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getIntroduction() {
            return introduction;
        }

        public void setIntroduction(String introduction) {
            this.introduction = introduction;
        }

        public ItemAdMonitorsBean getItem_ad_monitors() {
            return item_ad_monitors;
        }

        public void setItem_ad_monitors(ItemAdMonitorsBean item_ad_monitors) {
            this.item_ad_monitors = item_ad_monitors;
        }

        public boolean isLiked() {
            return liked;
        }

        public void setLiked(boolean liked) {
            this.liked = liked;
        }

        public int getLikes_count() {
            return likes_count;
        }

        public void setLikes_count(int likes_count) {
            this.likes_count = likes_count;
        }

        public Object getLimit_end_at() {
            return limit_end_at;
        }

        public void setLimit_end_at(Object limit_end_at) {
            this.limit_end_at = limit_end_at;
        }

        public int getPublished_at() {
            return published_at;
        }

        public void setPublished_at(int published_at) {
            this.published_at = published_at;
        }

        public String getShare_msg() {
            return share_msg;
        }

        public void setShare_msg(String share_msg) {
            this.share_msg = share_msg;
        }

        public int getShares_count() {
            return shares_count;
        }

        public void setShares_count(int shares_count) {
            this.shares_count = shares_count;
        }

        public String getShort_title() {
            return short_title;
        }

        public void setShort_title(String short_title) {
            this.short_title = short_title;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getTemplate() {
            return template;
        }

        public void setTemplate(String template) {
            this.template = template;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public int getUpdated_at() {
            return updated_at;
        }

        public void setUpdated_at(int updated_at) {
            this.updated_at = updated_at;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getContent_html() {
            return content_html;
        }

        public void setContent_html(String content_html) {
            this.content_html = content_html;
        }

        public List<?> getFeature_list() {
            return feature_list;
        }

        public void setFeature_list(List<?> feature_list) {
            this.feature_list = feature_list;
        }

        public List<?> getLabel_ids() {
            return label_ids;
        }

        public void setLabel_ids(List<?> label_ids) {
            this.label_ids = label_ids;
        }

        public static class ColumnBean {
            private String banner_image_url;
            private String category;
            private String cover_image_url;
            private int created_at;
            private String description;
            private int id;
            private int order;
            private int post_published_at;
            private int status;
            private String subtitle;
            private String title;
            private int updated_at;

            public String getBanner_image_url() {
                return banner_image_url;
            }

            public void setBanner_image_url(String banner_image_url) {
                this.banner_image_url = banner_image_url;
            }

            public String getCategory() {
                return category;
            }

            public void setCategory(String category) {
                this.category = category;
            }

            public String getCover_image_url() {
                return cover_image_url;
            }

            public void setCover_image_url(String cover_image_url) {
                this.cover_image_url = cover_image_url;
            }

            public int getCreated_at() {
                return created_at;
            }

            public void setCreated_at(int created_at) {
                this.created_at = created_at;
            }

            public String getDescription() {
                return description;
            }

            public void setDescription(String description) {
                this.description = description;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public int getOrder() {
                return order;
            }

            public void setOrder(int order) {
                this.order = order;
            }

            public int getPost_published_at() {
                return post_published_at;
            }

            public void setPost_published_at(int post_published_at) {
                this.post_published_at = post_published_at;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String getSubtitle() {
                return subtitle;
            }

            public void setSubtitle(String subtitle) {
                this.subtitle = subtitle;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getUpdated_at() {
                return updated_at;
            }

            public void setUpdated_at(int updated_at) {
                this.updated_at = updated_at;
            }
        }

        public static class ItemAdMonitorsBean {
        }
    }
}
