package com.gaowenyun.gift.model.bean;


//                            _ooOoo_  
//                           o8888888o  
//                           88" . "88  
//                           (| -_- |)  
//                            O\ = /O  
//                        ____/`---'\____  
//                      .   ' \\| |// `.  
//                       / \\||| : |||// \  
//                     / _||||| -:- |||||- \  
//                       | | \\\ - /// | |  
//                     | \_| ''\---/'' | |  
//                      \ .-\__ `-` ___/-. /  
//                   ___`. .' /--.--\ `. . __  
//                ."" '< `.___\_<|>_/___.' >'"".  
//               | | : `- \`.;`\ _ /`;.`/ - ` : | |  
//                 \ \ `-. \_ __\ /__ _/ .-` / /  
//         ======`-.____`-.___\_____/___.-`____.-'======  
//                            `=---='  
//  
//         .............................................  
//                  佛祖镇楼                  BUG辟易  
//          佛曰:  
//                  写字楼里写字间，写字间里程序员；  
//                  程序人员写程序，又拿程序换酒钱。  
//                  酒醒只在网上坐，酒醉还来网下眠；  
//                  酒醉酒醒日复日，网上网下年复年。  
//                  但愿老死电脑间，不愿鞠躬老板前；  
//                  奔驰宝马贵者趣，公交自行程序员。  
//                  别人笑我忒疯癫，我笑自己命太贱；  
//                  不见满街漂亮妹，哪个归得程序员？  


import java.util.List;

/**
 * Created by Administrator on 2016/11/5 0005.
 */
public class TypeMsgBean2 {

    /**
     * code : 200
     * data : {"items":[{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046105/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161014/jwjqsf9ah.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161014/jwjqsf9ah.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476944931,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1046105,"introduction":"寒冬来临，没有什么比暖暖的被窝更加舒服。在这个床品使用率最高的季节，选择一个适合自己的、优质的床品很有必要。今天小礼君给大家推荐几款温暖床品，如果寒冷只能自己承担，就要学会自己给自己温暖。","labels":[],"liked":false,"likes_count":23768,"limit_end_at":null,"media_type":0,"published_at":1476867600,"share_msg":"寒冬来临，没有什么比暖暖的被窝更加舒服。在这个床品使用率最高的季节，选择一个适合自己的、优质的床品很有必要。今天小礼君给大家推荐几款温暖床品，如果寒冷只能自己承担，就要学会自己给自己温暖。#全棉时代：第⑥款商品点击进入，该店铺18-20号全场7折优惠活动，千万不要错过啦#","short_title":"","status":0,"template":"","title":"#内有福利#秋冬季节那么好睡，我为什么要起床","type":"post","updated_at":1476956232,"url":"http://www.liwushuo.com/posts/1046105"},{"ad_monitors":[],"approved_at":1476697050,"author":{"avatar_url":"http://img01.liwushuo.com/image/160708/yactcsfo5.jpg","avatar_webp_url":null,"created_at":1467971922,"id":35,"introduction":"买遍全世界最低价","nickname":"凹凸曼"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160708/or81k6fea.jpg-w300","category":"礼物","cover_image_url":"http://img02.liwushuo.com/image/160720/xdt9kjriy.jpg-w720","created_at":1467970933,"description":"会买不一定\u201c惠\u201d买，每日10款超低价，举双手奉上。\u2014\u2014from亚马逊良心出品","id":90,"order":0,"post_published_at":1478228400,"status":0,"subtitle":"","title":"省钱大总攻","updated_at":1478251202},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046144/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/161017/viq2ygqab.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/161017/viq2ygqab.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476944914,"editor_id":1045,"feature_list":[],"hidden_cover_image":false,"id":1046144,"introduction":"偶尔也是忍不了自己的乱糟糟，虽说不用美如画，不过为了让生活更加舒心，置办个有格调的居室也很重要。简单便捷的吸尘器收拾下屋子各个角落，再放上个加湿器，让屋子呆起来更加舒适，再来上一杯营养果汁，做个美美的护理，舒服的简直不想再出门~","labels":[],"liked":false,"likes_count":7570,"limit_end_at":null,"media_type":0,"published_at":1476835200,"share_msg":"偶尔也是忍不了自己的乱糟糟，虽说不用美如画，不过为了让生活更加舒心，置办个有格调的居室也很重要。简单便捷的吸尘器收拾下屋子各个角落，再放上个加湿器，让屋子呆起来更加舒适，再来上一杯营养果汁，做个美美的护理，舒服的简直不想再出门~","short_title":"","status":0,"template":"","title":"家里不用美如画，格调舒适才得我心","type":"post","updated_at":1476780875,"url":"http://www.liwushuo.com/posts/1046144"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img02.liwushuo.com/image/160708/yactcsfo5.jpg","avatar_webp_url":null,"created_at":1467971922,"id":35,"introduction":"带你买遍全世界最低价","nickname":"凹凸曼"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160708/or81k6fea.jpg-w300","category":"礼物","cover_image_url":"http://img03.liwushuo.com/image/160720/xdt9kjriy.jpg-w720","created_at":1467970933,"description":"会买不一定\u201c惠\u201d买，每日10款超低价，举双手奉上。\u2014\u2014from亚马逊良心出品","id":90,"order":0,"post_published_at":1478228400,"status":0,"subtitle":"","title":"省钱大总攻","updated_at":1478251202},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046122/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161014/ykb0mjs7o.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161014/ykb0mjs7o.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476944897,"editor_id":1045,"feature_list":[],"hidden_cover_image":false,"id":1046122,"introduction":"虽然我们的假期余额已不足，但是回到家还是要享受舒舒服服的宅家生活。秋冬到了，温暖感很重要，柔软的棉拖、速干的干发帽、温馨的小夜灯都很实用。宅的舒服了，心情好的时候，还可以顺手收拾下房间，有了这些神奇小物，连家务活都变得没那么讨厌～","labels":[],"liked":false,"likes_count":9442,"limit_end_at":null,"media_type":null,"published_at":1476748800,"share_msg":"虽然我们的假期余额已不足，但是回到家还是要享受舒舒服服的宅家生活。秋冬到了，温暖感很重要，柔软的棉拖、速干的干发帽、温馨的小夜灯都很实用。宅的舒服了，心情好的时候，还可以顺手收拾下房间，有了这些神奇小物，连家务活都变得没那么讨厌～","short_title":"","status":0,"template":"","title":"家居折扣场：生活如此美好，都想抢着干家务","type":"post","updated_at":1476700368,"url":"http://www.liwushuo.com/posts/1046122"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img03.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046069/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161010/fzdaf0wzz.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161010/fzdaf0wzz.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476944871,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1046069,"introduction":"每次去路过家居店就想进去逛荡一圈，看到慵懒的沙发就想一屁股坐在上面，把自己种在上面，就这么静静的待一下午，懒人沙发，没有骨架，随意造型，可以把整个人窝在里面享受慵懒的私人空间。下面这10款懒人沙发可别错过了哟。","labels":[],"liked":false,"likes_count":21123,"limit_end_at":null,"media_type":null,"published_at":1476694800,"share_msg":"每次去路过家居店就想进去逛荡一圈，看到慵懒的沙发就想一屁股坐在上面，有一种想把自己种在上面的冲动，就这么静静的待一下午。懒人沙发呢，没有骨架，随意造型，可以把整个人窝在里面享受慵懒的私人空间。下面这10款懒人沙发可别错过了哟。","short_title":"","status":0,"template":"","title":"舒舒服服宅在家，懒人沙发才是标配","type":"post","updated_at":1476669720,"url":"http://www.liwushuo.com/posts/1046069"},{"ad_monitors":[],"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/ozwl236qx.jpg","avatar_webp_url":null,"created_at":1465974288,"id":9,"introduction":"礼物界的老司机","nickname":"小C"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/kd1dy4pi3.jpg-w300","category":"礼物","cover_image_url":"http://img01.liwushuo.com/image/160713/y2arp77qx.jpg-w720","created_at":1462501381,"description":"如果青春不会散场，时光可以珍藏。如果你的每一个米粒大小念想，都能找到与之匹配的美物安放...这样的店你会不会来？","id":5,"order":0,"post_published_at":1477969200,"status":0,"subtitle":"","title":"不打烊的礼物店","updated_at":1478079307},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045861/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/160928/mm8zvfox8.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160928/mm8zvfox8.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476329003,"editor_id":1137,"feature_list":[],"hidden_cover_image":false,"id":1045861,"introduction":"还有什么能比橙色系更能代表秋天？枫叶的绚烂、甜橙的甘香，秋收的充盈、夕阳西下的温暖......介于红色与黄色之间的游离地带，而独有一份欢乐的色感，明快而又温馨，给Ta带去深秋的问候~","labels":[],"liked":false,"likes_count":6762,"limit_end_at":null,"published_at":1475722800,"share_msg":"还有什么能比橙色系更能代表秋天？枫叶的绚烂、甜橙的甘香，秋收的充盈、夕阳西下的温暖......介于红色与黄色之间的游离地带，而独有一份欢乐的色感，明快而又温馨，给Ta带去深秋的问候~","short_title":"","status":0,"template":"","title":"回归秋日色调，愿Ta的生活心想事\u201c橙\u201d","type":"post","updated_at":1475326252,"url":"http://www.liwushuo.com/posts/1045861"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img02.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046049/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/161009/5il44zbkz.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/161009/5il44zbkz.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328963,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1046049,"introduction":"走进一间都是关于大自然的家里，打开门的那瞬间你所看到的都是自然之境时，那会有多舒服啊。尽管在外面遇到了多少的压力与不愉快，只要进了家里坏心情通通都烟消云散了。如果恰好你也喜欢这种自然风格，那么停下脚步来花几分钟来欣赏这些美物给你带来的好心情吧。","labels":[],"liked":false,"likes_count":9756,"limit_end_at":null,"published_at":1476328963,"share_msg":"走进一间都是关于大自然的家里，打开门的那瞬间你所看到的都是自然之境时，那会有多舒服啊。尽管在外面遇到了多少的压力与不愉快，只要进了家里坏心情通通都烟消云散了。如果恰好你也喜欢这种自然风格，那么停下脚步来花几分钟来欣赏这些美物给你带来的好心情吧。","short_title":"","status":0,"template":"","title":"回归\u201c大自然\u201d本色，还你一个清新自然的家","type":"post","updated_at":1476328963,"url":"http://www.liwushuo.com/posts/1046049"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img02.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045892/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160928/pqeqmqarr.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160928/pqeqmqarr.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328948,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045892,"introduction":"冯唐说过， 我要用尽我的万种风情， 让你在将来任何不和我在一起的时候， 内心无法安宁。","labels":[],"liked":false,"likes_count":15514,"limit_end_at":null,"published_at":1475744400,"share_msg":"冯唐说过，","short_title":"","status":0,"template":"","title":"给留白的空间多一点想象","type":"post","updated_at":1475325155,"url":"http://www.liwushuo.com/posts/1045892"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045864/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/160928/cba2a35g2.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160928/cba2a35g2.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328941,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045864,"introduction":"你一定也遇到过这样的问题：一时冲动买买买，然后就再也没有用过的东西想着\u201c总有一天会用到\u201d，结果积了一整年的灰好不容易花时间收拾了，结果过几天又乱了。这样不停死循环的人生！怎么破？","labels":[],"liked":false,"likes_count":20565,"limit_end_at":null,"published_at":1475312400,"share_msg":"你一定也遇到过这样的问题：一时冲动买买买，然后就再也没有用过的东西想着\u201c总有一天会用到\u201d，结果积了一整年的灰好不容易花时间收拾了，结果过几天又乱了。这样不停死循环的人生！怎么破？","short_title":"","status":0,"template":"","title":"原谅我一生放荡不羁东西多，还好我是个收纳狂魔","type":"post","updated_at":1475229585,"url":"http://www.liwushuo.com/posts/1045864"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img03.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045636/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161017/639upbali.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161017/639upbali.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328925,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045636,"introduction":"年轻一点的时候，对生活的热情基本都投入了想象的黑洞，\u201c等我有了自己的公寓要怎样怎么样\u201d \u201c等我有了自己带院子的房子要怎样怎样\u201d\u2026\u2026就是无法抬起手指先把自己厨房水槽里放了好几天的碗洗了，因为在那个愿景实现前，\u201c就先凑合下好了\u201d。","labels":[],"liked":false,"likes_count":1117,"limit_end_at":null,"media_type":0,"published_at":1473757200,"share_msg":"年轻一点的时候，对生活的热情基本都投入了想象的黑洞，\u201c等我有了自己的公寓要怎样怎么样\u201d \u201c等我有了自己带院子的房子要怎样怎样\u201d\u2026\u2026就是无法抬起手指先把自己厨房水槽里放了好几天的碗洗了，因为在那个愿景实现前，\u201c就先凑合下好了\u201d。","short_title":"","status":0,"template":"","title":"第59期｜美家靠你\u201c装\u201d出来","type":"post","updated_at":1476692460,"url":"http://www.liwushuo.com/posts/1045636"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045663/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161017/6xwp8m7jy.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161017/6xwp8m7jy.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328919,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045663,"introduction":"卧室的床头灯，不止在起夜时方便照明、调节氛围，还是卧室装饰、布置的一大亮点。但对于选择困难户来说，选一款什么样的台灯真的是难为他们了。所以，小礼君给大家安利了10款美美的台灯，总有一款你会想拔草吧～","labels":[],"liked":false,"likes_count":13681,"limit_end_at":null,"media_type":0,"published_at":1473584400,"share_msg":"卧室的床头灯，不止在起夜时方便照明、调节氛围，还是卧室装饰、布置的一大亮点。但对于选择困难户来说，选一款什么样的台灯真的是难为他们了。所以，小礼君给大家安利了10款美美的台灯，总有一款你会想拔草吧～","short_title":"","status":0,"template":"","title":"第58期｜留一盏床头灯，和亲爱的Ta说晚安","type":"post","updated_at":1476692539,"url":"http://www.liwushuo.com/posts/1045663"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045452/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161017/x4431ybc3.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161017/x4431ybc3.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328903,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045452,"introduction":"你的书桌还在杂乱不堪么？处女座根本无法忍受。想随手阅读的时候还要去书架上苦苦寻找？简直太麻烦了。想提升家的档次又不想总买装饰品，这更犯难了。","labels":[],"liked":false,"likes_count":12082,"limit_end_at":null,"media_type":0,"published_at":1472547600,"share_msg":"你的书桌还在杂乱不堪么？处女座根本无法忍受。想随手阅读的时候还要去书架上苦苦寻找？简直太麻烦了。想提升家的档次又不想总买装饰品，这更犯难了。","short_title":"","status":0,"template":"","title":"第53期｜几款书立便能轻松搞定杂乱书桌","type":"post","updated_at":1476692627,"url":"http://www.liwushuo.com/posts/1045452"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img02.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045373/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/161017/g90futge7.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/161017/g90futge7.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328895,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045373,"introduction":"要缓解疲累，其实除了补充精力，重要的还是让身体得到解放。通常睡前，大多数人会把床弄得舒服点，手机为飞行模式，音乐准备好，抱枕在侧，躺着看一会儿书或一部电影、电视剧，享受夜晚一个人的好时光～","labels":[],"liked":false,"likes_count":16909,"limit_end_at":null,"media_type":0,"published_at":1472288400,"share_msg":"要缓解疲累，其实除了补充精力，重要的还是让身体得到解放。通常睡前，大多数人会把床弄得舒服点，手机为飞行模式，音乐准备好，抱枕在侧，躺着看一会儿书或一部电影、电视剧，享受夜晚一个人的好时光～","short_title":"","status":0,"template":"","title":"第52期｜睡眠大过天，别让你的枕头毁掉你的睡眠","type":"post","updated_at":1476692753,"url":"http://www.liwushuo.com/posts/1045373"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img02.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045407/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/161017/6woy77tih.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/161017/6woy77tih.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328886,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045407,"introduction":"五颜六色的鲜花总是寄托了人们的美好愿望，人们也总是喜欢用花来表达对生活的情感。而小编却总是对那些精致的花瓶情有独钟，因为花瓶本身就是一件艺术品。家里有那么几件精致的花瓶，不仅能为花朵增添几分艳丽，更能彰显出主人的品味。","labels":[],"liked":false,"likes_count":15127,"limit_end_at":null,"media_type":0,"published_at":1472115600,"share_msg":"五颜六色的鲜花总是寄托了人们的美好愿望，人们也总是喜欢用花来表达对生活的情感。而小编却总是对那些精致的花瓶情有独钟，因为花瓶本身就是一件艺术品。家里有那么几件精致的花瓶，不仅能为花朵增添几分艳丽，更能彰显出主人的品味。","short_title":"","status":0,"template":"","title":"第51期｜用花瓶打造的居家艺术","type":"post","updated_at":1476692872,"url":"http://www.liwushuo.com/posts/1045407"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045289/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161017/da7ie2lzr.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161017/da7ie2lzr.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328879,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045289,"introduction":".","labels":[],"liked":false,"likes_count":34176,"limit_end_at":null,"media_type":0,"published_at":1471942800,"share_msg":"开学季，打造温馨宿舍离不开必备的床上三件套。每天要与它共眠，柔软舒适肯定是必不可少的。然而，赏心悦目的图案、鲜明的个人风格自然也是不可忽视的。需要一起睡好久的伴侣怎能不精心挑选？有人@你，你的宿舍三件套送到了，请签收。","short_title":"","status":0,"template":"","title":"第50期｜在宿舍床上梦一个理想","type":"post","updated_at":1476693023,"url":"http://www.liwushuo.com/posts/1045289"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img02.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img03.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045285/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/160822/aavh1juwp.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160822/aavh1juwp.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328869,"editor_id":1023,"feature_list":[],"hidden_cover_image":false,"id":1045285,"introduction":"对于学生党来说，宿舍就是第二个家，所以当然要把它布置得舒适、温馨才行！之前小礼君出过许多宿舍神器的攻略，并且深受大家的欢迎，那么今天就再来一发宿舍好物合辑，让你的舍友羡慕去吧~","labels":[],"liked":false,"likes_count":61957,"limit_end_at":null,"published_at":-28800,"share_msg":"对于学生党来说，宿舍就是第二个家，所以当然要把它布置得舒适、温馨才行！之前小礼君出过许多宿舍神器的攻略，并且深受大家的欢迎，那么今天就再来一发宿舍好物合辑，让你的舍友羡慕去吧~","short_title":"","status":0,"template":"","title":"40件学生党必备宿舍神器","type":"post","updated_at":1473329101,"url":"http://www.liwushuo.com/posts/1045285"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img03.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045243/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/160817/uk1su2jbp.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160817/uk1su2jbp.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328863,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045243,"introduction":"对于梳妆收纳，相信每个女生都非常头大。每天匆忙化妆就出门，来不及收拾，晚上回来看到梳妆台散乱无章的瓶瓶罐罐，总是毫无头绪。其实化妆品们也应该来个大扫除！眼影、腮红、化妆刷\u2026\u2026堆在一起用起来非常不方便，而且容易滋生细菌。如何将这些繁杂的化妆品安排得井井有条，甚至变成房间里有设计感的一角？下面跟着小礼君一起来学吧～","labels":[],"liked":false,"likes_count":18260,"limit_end_at":null,"published_at":1471489200,"share_msg":"对于梳妆收纳，相信每个女生都非常头大。每天匆忙化妆就出门，来不及收拾，晚上回来看到梳妆台散乱无章的瓶瓶罐罐，总是毫无头绪。其实化妆品们也应该来个大扫除！眼影、腮红、化妆刷\u2026\u2026堆在一起用起来非常不方便，而且容易滋生细菌。如何将这些繁杂的化妆品安排得井井有条，甚至变成房间里有设计感的一角？下面跟着小礼君一起来学吧～","short_title":"","status":0,"template":"","title":"第48期 | 你不能或缺の梳妆收纳好物","type":"post","updated_at":1471486218,"url":"http://www.liwushuo.com/posts/1045243"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img02.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045067/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160809/ydcj9unb1.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160809/ydcj9unb1.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328855,"editor_id":1147,"feature_list":[],"hidden_cover_image":false,"id":1045067,"introduction":"一只小小的抱枕，虽然并不起眼，但让我们拥有实实在在的安全感。即使孤身一人漂泊在外地，无论是住着出租房抑或学校宿舍，可抱着它带来的心安，总能溢出满满的幸福感，有种归家的暖心感觉。 它会在你疲惫、心累的时候，陪我们躺着，让我们拥在怀里，给我们\u201c依靠\u201d，更像是我们最忠诚的伴侣。所以，这种暖心有爱的小物件小礼君怎能放过，必定要推荐给我的伙伴们啦~","labels":[],"liked":false,"likes_count":25185,"limit_end_at":null,"published_at":1471046400,"share_msg":"一只小小的抱枕，虽然并不起眼，但让我们拥有实实在在的安全感。即使孤身一人漂泊在外地，无论是住着出租房抑或学校宿舍，可抱着它带来的心安，总能溢出满满的幸福感，有种归家的暖心感觉。 它会在你疲惫、心累的时候，陪我们躺着，让我们拥在怀里，给我们\u201c依靠\u201d，更像是我们最忠诚的伴侣。所以，这种暖心有爱的小物件小礼君怎能放过，必定要推荐给我的伙伴们啦~","short_title":"","status":0,"template":"","title":"第47期 | 小抱枕，大幸福","type":"post","updated_at":1470998376,"url":"http://www.liwushuo.com/posts/1045067"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img03.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1044609/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/160715/174ynnm12.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/160715/174ynnm12.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328839,"editor_id":1023,"feature_list":[],"hidden_cover_image":false,"id":1044609,"introduction":"家里面的舒适干净是很重要的，谁都不想要每天回到家以后看到的是四处乱丢的脏衣服、是翻的乱七八糟的杂志还有东一只西一只的鞋子，总之想要有一个舒适的环境，省心方便的收纳装备是必不可少的！对于家里东西很多的宝宝来说，收纳简直就是拯救居住环境的大杀器，看着所有东西都被摆放的井井有条就有一种超级满足的感觉~\\(≧▽≦)/~","labels":[],"liked":false,"likes_count":32725,"limit_end_at":null,"published_at":1468627260,"share_msg":"家里面的舒适干净是很重要的，谁都不想要每天回到家以后看到的是四处乱丢的脏衣服、是翻的乱七八糟的杂志还有东一只西一只的鞋子，总之想要有一个舒适的环境，省心方便的收纳装备是必不可少的！对于家里东西很多的宝宝来说，收纳简直就是拯救居住环境的大杀器，看着所有东西都被摆放的井井有条就有一种超级满足的感觉~\\(≧▽≦)/~","short_title":"收纳","status":0,"template":"","title":"收纳神器在此，\u201c纳\u201d都不是事","type":"post","updated_at":1468665527,"url":"http://www.liwushuo.com/posts/1044609"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160617/hzkkl1ohn.jpg","avatar_webp_url":null,"created_at":1465802857,"id":1,"introduction":"资深买买买达人","nickname":"小礼君"},"column":{"banner_image_url":"http://img02.liwushuo.com/image/160815/v2p80ao8y.jpg-w300","category":"礼物","cover_image_url":"http://img03.liwushuo.com/image/160815/fervz0o5x.jpg-w720","created_at":1471225655,"description":"品质、考究、精心遴选；细节、严格、甄添筛减；处女座强迫症的挑选小组，一份有态度的最佳礼物大赏。","id":94,"order":0,"post_published_at":1476860400,"status":0,"subtitle":"","title":"最佳礼物大赏","updated_at":1477241447},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045035/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/160812/4gsn1vycr.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160812/4gsn1vycr.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328838,"editor_id":1058,"feature_list":[],"hidden_cover_image":false,"id":1045035,"introduction":"每个人肯定都有孤独的时候，也会有无助的时候，也总免不了想要有一个人陪，却恰好智能自己的时候，这个时候也不要\u201c自甘堕落\u201d啦~还有他们陪你嘛！各式各样可爱激萌的抱枕，不管是陪伴你，还是替你陪伴别人，都是很好地选择哦~礼物说星人共同的选择，可爱抱枕TOP来袭！","labels":[],"liked":false,"likes_count":21167,"limit_end_at":null,"published_at":1472612400,"share_msg":"每个人肯定都有孤独的时候，也会有无助的时候，也总免不了想要有一个人陪，却恰好智能自己的时候，这个时候也不要\u201c自甘堕落\u201d啦~还有他们陪你嘛！各式各样可爱激萌的抱枕，不管是陪伴你，还是替你陪伴别人，都是很好地选择哦~礼物说星人共同的选择，可爱抱枕TOP来袭！","short_title":"","status":0,"template":"","title":"想要俘获萌妹柔软心？是时候祭出可爱抱枕了","type":"post","updated_at":1474969907,"url":"http://www.liwushuo.com/posts/1045035"},{"ad_monitors":[],"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img03.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1044022/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160624/n3dvub7eh.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160624/n3dvub7eh.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328831,"editor_id":1058,"feature_list":[],"hidden_cover_image":false,"id":1044022,"introduction":"不管是什么性格的女生，不管是什么年龄的女生，他们的心里都会有一个公主的灵魂。虽然也许因为各种原因不能走少女风，或者不喜欢全部都是粉粉的少女感，但总要有一个地方保持和维护住自己的这份少女梦才是对自己真的好嘛。那么，这个地方肯定就是卧室啦~私人安全地带，肯定是释放心底小秘密的绝佳之处！如果你又是恰好不喜欢满房间都是纷纷的少女感的话，那就从这里挑一些小小物件，摆在屋子里，一定会让你的屋子大变样的！","labels":[],"liked":false,"likes_count":27346,"limit_end_at":null,"published_at":1466812800,"share_msg":"不管是什么性格的女生，不管是什么年龄的女生，他们的心里都会有一个公主的灵魂。虽然也许因为各种原因不能走少女风，或者不喜欢全部都是粉粉的少女感，但总要有一个地方保持和维护住自己的这份少女梦才是对自己真的好嘛。那么，这个地方肯定就是卧室啦~私人安全地带，肯定是释放心底小秘密的绝佳之处！如果你又是恰好不喜欢满房间都是纷纷的少女感的话，那就从这里挑一些小小物件，摆在屋子里，一定会让你的屋子大变样的！","short_title":"少女心卧室","status":0,"template":"","title":"第41期 | 小东西大改造，少女宝宝的专属卧室GET√","type":"post","updated_at":1466760770,"url":"http://www.liwushuo.com/posts/1044022"}],"paging":{"next_url":"http://api.liwushuo.com/v2/channels/112/items_v2?order_by=now&limit=20&offset=20"}}
     * message : OK
     */

    private int code;
    /**
     * items : [{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046105/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161014/jwjqsf9ah.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161014/jwjqsf9ah.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476944931,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1046105,"introduction":"寒冬来临，没有什么比暖暖的被窝更加舒服。在这个床品使用率最高的季节，选择一个适合自己的、优质的床品很有必要。今天小礼君给大家推荐几款温暖床品，如果寒冷只能自己承担，就要学会自己给自己温暖。","labels":[],"liked":false,"likes_count":23768,"limit_end_at":null,"media_type":0,"published_at":1476867600,"share_msg":"寒冬来临，没有什么比暖暖的被窝更加舒服。在这个床品使用率最高的季节，选择一个适合自己的、优质的床品很有必要。今天小礼君给大家推荐几款温暖床品，如果寒冷只能自己承担，就要学会自己给自己温暖。#全棉时代：第⑥款商品点击进入，该店铺18-20号全场7折优惠活动，千万不要错过啦#","short_title":"","status":0,"template":"","title":"#内有福利#秋冬季节那么好睡，我为什么要起床","type":"post","updated_at":1476956232,"url":"http://www.liwushuo.com/posts/1046105"},{"ad_monitors":[],"approved_at":1476697050,"author":{"avatar_url":"http://img01.liwushuo.com/image/160708/yactcsfo5.jpg","avatar_webp_url":null,"created_at":1467971922,"id":35,"introduction":"买遍全世界最低价","nickname":"凹凸曼"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160708/or81k6fea.jpg-w300","category":"礼物","cover_image_url":"http://img02.liwushuo.com/image/160720/xdt9kjriy.jpg-w720","created_at":1467970933,"description":"会买不一定\u201c惠\u201d买，每日10款超低价，举双手奉上。\u2014\u2014from亚马逊良心出品","id":90,"order":0,"post_published_at":1478228400,"status":0,"subtitle":"","title":"省钱大总攻","updated_at":1478251202},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046144/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/161017/viq2ygqab.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/161017/viq2ygqab.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476944914,"editor_id":1045,"feature_list":[],"hidden_cover_image":false,"id":1046144,"introduction":"偶尔也是忍不了自己的乱糟糟，虽说不用美如画，不过为了让生活更加舒心，置办个有格调的居室也很重要。简单便捷的吸尘器收拾下屋子各个角落，再放上个加湿器，让屋子呆起来更加舒适，再来上一杯营养果汁，做个美美的护理，舒服的简直不想再出门~","labels":[],"liked":false,"likes_count":7570,"limit_end_at":null,"media_type":0,"published_at":1476835200,"share_msg":"偶尔也是忍不了自己的乱糟糟，虽说不用美如画，不过为了让生活更加舒心，置办个有格调的居室也很重要。简单便捷的吸尘器收拾下屋子各个角落，再放上个加湿器，让屋子呆起来更加舒适，再来上一杯营养果汁，做个美美的护理，舒服的简直不想再出门~","short_title":"","status":0,"template":"","title":"家里不用美如画，格调舒适才得我心","type":"post","updated_at":1476780875,"url":"http://www.liwushuo.com/posts/1046144"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img02.liwushuo.com/image/160708/yactcsfo5.jpg","avatar_webp_url":null,"created_at":1467971922,"id":35,"introduction":"带你买遍全世界最低价","nickname":"凹凸曼"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160708/or81k6fea.jpg-w300","category":"礼物","cover_image_url":"http://img03.liwushuo.com/image/160720/xdt9kjriy.jpg-w720","created_at":1467970933,"description":"会买不一定\u201c惠\u201d买，每日10款超低价，举双手奉上。\u2014\u2014from亚马逊良心出品","id":90,"order":0,"post_published_at":1478228400,"status":0,"subtitle":"","title":"省钱大总攻","updated_at":1478251202},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046122/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161014/ykb0mjs7o.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161014/ykb0mjs7o.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476944897,"editor_id":1045,"feature_list":[],"hidden_cover_image":false,"id":1046122,"introduction":"虽然我们的假期余额已不足，但是回到家还是要享受舒舒服服的宅家生活。秋冬到了，温暖感很重要，柔软的棉拖、速干的干发帽、温馨的小夜灯都很实用。宅的舒服了，心情好的时候，还可以顺手收拾下房间，有了这些神奇小物，连家务活都变得没那么讨厌～","labels":[],"liked":false,"likes_count":9442,"limit_end_at":null,"media_type":null,"published_at":1476748800,"share_msg":"虽然我们的假期余额已不足，但是回到家还是要享受舒舒服服的宅家生活。秋冬到了，温暖感很重要，柔软的棉拖、速干的干发帽、温馨的小夜灯都很实用。宅的舒服了，心情好的时候，还可以顺手收拾下房间，有了这些神奇小物，连家务活都变得没那么讨厌～","short_title":"","status":0,"template":"","title":"家居折扣场：生活如此美好，都想抢着干家务","type":"post","updated_at":1476700368,"url":"http://www.liwushuo.com/posts/1046122"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img03.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046069/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161010/fzdaf0wzz.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161010/fzdaf0wzz.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476944871,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1046069,"introduction":"每次去路过家居店就想进去逛荡一圈，看到慵懒的沙发就想一屁股坐在上面，把自己种在上面，就这么静静的待一下午，懒人沙发，没有骨架，随意造型，可以把整个人窝在里面享受慵懒的私人空间。下面这10款懒人沙发可别错过了哟。","labels":[],"liked":false,"likes_count":21123,"limit_end_at":null,"media_type":null,"published_at":1476694800,"share_msg":"每次去路过家居店就想进去逛荡一圈，看到慵懒的沙发就想一屁股坐在上面，有一种想把自己种在上面的冲动，就这么静静的待一下午。懒人沙发呢，没有骨架，随意造型，可以把整个人窝在里面享受慵懒的私人空间。下面这10款懒人沙发可别错过了哟。","short_title":"","status":0,"template":"","title":"舒舒服服宅在家，懒人沙发才是标配","type":"post","updated_at":1476669720,"url":"http://www.liwushuo.com/posts/1046069"},{"ad_monitors":[],"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/ozwl236qx.jpg","avatar_webp_url":null,"created_at":1465974288,"id":9,"introduction":"礼物界的老司机","nickname":"小C"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/kd1dy4pi3.jpg-w300","category":"礼物","cover_image_url":"http://img01.liwushuo.com/image/160713/y2arp77qx.jpg-w720","created_at":1462501381,"description":"如果青春不会散场，时光可以珍藏。如果你的每一个米粒大小念想，都能找到与之匹配的美物安放...这样的店你会不会来？","id":5,"order":0,"post_published_at":1477969200,"status":0,"subtitle":"","title":"不打烊的礼物店","updated_at":1478079307},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045861/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/160928/mm8zvfox8.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160928/mm8zvfox8.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476329003,"editor_id":1137,"feature_list":[],"hidden_cover_image":false,"id":1045861,"introduction":"还有什么能比橙色系更能代表秋天？枫叶的绚烂、甜橙的甘香，秋收的充盈、夕阳西下的温暖......介于红色与黄色之间的游离地带，而独有一份欢乐的色感，明快而又温馨，给Ta带去深秋的问候~","labels":[],"liked":false,"likes_count":6762,"limit_end_at":null,"published_at":1475722800,"share_msg":"还有什么能比橙色系更能代表秋天？枫叶的绚烂、甜橙的甘香，秋收的充盈、夕阳西下的温暖......介于红色与黄色之间的游离地带，而独有一份欢乐的色感，明快而又温馨，给Ta带去深秋的问候~","short_title":"","status":0,"template":"","title":"回归秋日色调，愿Ta的生活心想事\u201c橙\u201d","type":"post","updated_at":1475326252,"url":"http://www.liwushuo.com/posts/1045861"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img02.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046049/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/161009/5il44zbkz.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/161009/5il44zbkz.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328963,"editor_id":1018,"feature_list":[],"hidden_cover_image":false,"id":1046049,"introduction":"走进一间都是关于大自然的家里，打开门的那瞬间你所看到的都是自然之境时，那会有多舒服啊。尽管在外面遇到了多少的压力与不愉快，只要进了家里坏心情通通都烟消云散了。如果恰好你也喜欢这种自然风格，那么停下脚步来花几分钟来欣赏这些美物给你带来的好心情吧。","labels":[],"liked":false,"likes_count":9756,"limit_end_at":null,"published_at":1476328963,"share_msg":"走进一间都是关于大自然的家里，打开门的那瞬间你所看到的都是自然之境时，那会有多舒服啊。尽管在外面遇到了多少的压力与不愉快，只要进了家里坏心情通通都烟消云散了。如果恰好你也喜欢这种自然风格，那么停下脚步来花几分钟来欣赏这些美物给你带来的好心情吧。","short_title":"","status":0,"template":"","title":"回归\u201c大自然\u201d本色，还你一个清新自然的家","type":"post","updated_at":1476328963,"url":"http://www.liwushuo.com/posts/1046049"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img02.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045892/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160928/pqeqmqarr.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160928/pqeqmqarr.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328948,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045892,"introduction":"冯唐说过， 我要用尽我的万种风情， 让你在将来任何不和我在一起的时候， 内心无法安宁。","labels":[],"liked":false,"likes_count":15514,"limit_end_at":null,"published_at":1475744400,"share_msg":"冯唐说过，","short_title":"","status":0,"template":"","title":"给留白的空间多一点想象","type":"post","updated_at":1475325155,"url":"http://www.liwushuo.com/posts/1045892"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045864/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/160928/cba2a35g2.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160928/cba2a35g2.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328941,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045864,"introduction":"你一定也遇到过这样的问题：一时冲动买买买，然后就再也没有用过的东西想着\u201c总有一天会用到\u201d，结果积了一整年的灰好不容易花时间收拾了，结果过几天又乱了。这样不停死循环的人生！怎么破？","labels":[],"liked":false,"likes_count":20565,"limit_end_at":null,"published_at":1475312400,"share_msg":"你一定也遇到过这样的问题：一时冲动买买买，然后就再也没有用过的东西想着\u201c总有一天会用到\u201d，结果积了一整年的灰好不容易花时间收拾了，结果过几天又乱了。这样不停死循环的人生！怎么破？","short_title":"","status":0,"template":"","title":"原谅我一生放荡不羁东西多，还好我是个收纳狂魔","type":"post","updated_at":1475229585,"url":"http://www.liwushuo.com/posts/1045864"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img03.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045636/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161017/639upbali.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161017/639upbali.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328925,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045636,"introduction":"年轻一点的时候，对生活的热情基本都投入了想象的黑洞，\u201c等我有了自己的公寓要怎样怎么样\u201d \u201c等我有了自己带院子的房子要怎样怎样\u201d\u2026\u2026就是无法抬起手指先把自己厨房水槽里放了好几天的碗洗了，因为在那个愿景实现前，\u201c就先凑合下好了\u201d。","labels":[],"liked":false,"likes_count":1117,"limit_end_at":null,"media_type":0,"published_at":1473757200,"share_msg":"年轻一点的时候，对生活的热情基本都投入了想象的黑洞，\u201c等我有了自己的公寓要怎样怎么样\u201d \u201c等我有了自己带院子的房子要怎样怎样\u201d\u2026\u2026就是无法抬起手指先把自己厨房水槽里放了好几天的碗洗了，因为在那个愿景实现前，\u201c就先凑合下好了\u201d。","short_title":"","status":0,"template":"","title":"第59期｜美家靠你\u201c装\u201d出来","type":"post","updated_at":1476692460,"url":"http://www.liwushuo.com/posts/1045636"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045663/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161017/6xwp8m7jy.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161017/6xwp8m7jy.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328919,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045663,"introduction":"卧室的床头灯，不止在起夜时方便照明、调节氛围，还是卧室装饰、布置的一大亮点。但对于选择困难户来说，选一款什么样的台灯真的是难为他们了。所以，小礼君给大家安利了10款美美的台灯，总有一款你会想拔草吧～","labels":[],"liked":false,"likes_count":13681,"limit_end_at":null,"media_type":0,"published_at":1473584400,"share_msg":"卧室的床头灯，不止在起夜时方便照明、调节氛围，还是卧室装饰、布置的一大亮点。但对于选择困难户来说，选一款什么样的台灯真的是难为他们了。所以，小礼君给大家安利了10款美美的台灯，总有一款你会想拔草吧～","short_title":"","status":0,"template":"","title":"第58期｜留一盏床头灯，和亲爱的Ta说晚安","type":"post","updated_at":1476692539,"url":"http://www.liwushuo.com/posts/1045663"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045452/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161017/x4431ybc3.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161017/x4431ybc3.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328903,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045452,"introduction":"你的书桌还在杂乱不堪么？处女座根本无法忍受。想随手阅读的时候还要去书架上苦苦寻找？简直太麻烦了。想提升家的档次又不想总买装饰品，这更犯难了。","labels":[],"liked":false,"likes_count":12082,"limit_end_at":null,"media_type":0,"published_at":1472547600,"share_msg":"你的书桌还在杂乱不堪么？处女座根本无法忍受。想随手阅读的时候还要去书架上苦苦寻找？简直太麻烦了。想提升家的档次又不想总买装饰品，这更犯难了。","short_title":"","status":0,"template":"","title":"第53期｜几款书立便能轻松搞定杂乱书桌","type":"post","updated_at":1476692627,"url":"http://www.liwushuo.com/posts/1045452"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img02.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045373/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/161017/g90futge7.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/161017/g90futge7.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328895,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045373,"introduction":"要缓解疲累，其实除了补充精力，重要的还是让身体得到解放。通常睡前，大多数人会把床弄得舒服点，手机为飞行模式，音乐准备好，抱枕在侧，躺着看一会儿书或一部电影、电视剧，享受夜晚一个人的好时光～","labels":[],"liked":false,"likes_count":16909,"limit_end_at":null,"media_type":0,"published_at":1472288400,"share_msg":"要缓解疲累，其实除了补充精力，重要的还是让身体得到解放。通常睡前，大多数人会把床弄得舒服点，手机为飞行模式，音乐准备好，抱枕在侧，躺着看一会儿书或一部电影、电视剧，享受夜晚一个人的好时光～","short_title":"","status":0,"template":"","title":"第52期｜睡眠大过天，别让你的枕头毁掉你的睡眠","type":"post","updated_at":1476692753,"url":"http://www.liwushuo.com/posts/1045373"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img02.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045407/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/161017/6woy77tih.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/161017/6woy77tih.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328886,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045407,"introduction":"五颜六色的鲜花总是寄托了人们的美好愿望，人们也总是喜欢用花来表达对生活的情感。而小编却总是对那些精致的花瓶情有独钟，因为花瓶本身就是一件艺术品。家里有那么几件精致的花瓶，不仅能为花朵增添几分艳丽，更能彰显出主人的品味。","labels":[],"liked":false,"likes_count":15127,"limit_end_at":null,"media_type":0,"published_at":1472115600,"share_msg":"五颜六色的鲜花总是寄托了人们的美好愿望，人们也总是喜欢用花来表达对生活的情感。而小编却总是对那些精致的花瓶情有独钟，因为花瓶本身就是一件艺术品。家里有那么几件精致的花瓶，不仅能为花朵增添几分艳丽，更能彰显出主人的品味。","short_title":"","status":0,"template":"","title":"第51期｜用花瓶打造的居家艺术","type":"post","updated_at":1476692872,"url":"http://www.liwushuo.com/posts/1045407"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045289/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161017/da7ie2lzr.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161017/da7ie2lzr.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328879,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045289,"introduction":".","labels":[],"liked":false,"likes_count":34176,"limit_end_at":null,"media_type":0,"published_at":1471942800,"share_msg":"开学季，打造温馨宿舍离不开必备的床上三件套。每天要与它共眠，柔软舒适肯定是必不可少的。然而，赏心悦目的图案、鲜明的个人风格自然也是不可忽视的。需要一起睡好久的伴侣怎能不精心挑选？有人@你，你的宿舍三件套送到了，请签收。","short_title":"","status":0,"template":"","title":"第50期｜在宿舍床上梦一个理想","type":"post","updated_at":1476693023,"url":"http://www.liwushuo.com/posts/1045289"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img02.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img03.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045285/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/160822/aavh1juwp.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160822/aavh1juwp.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328869,"editor_id":1023,"feature_list":[],"hidden_cover_image":false,"id":1045285,"introduction":"对于学生党来说，宿舍就是第二个家，所以当然要把它布置得舒适、温馨才行！之前小礼君出过许多宿舍神器的攻略，并且深受大家的欢迎，那么今天就再来一发宿舍好物合辑，让你的舍友羡慕去吧~","labels":[],"liked":false,"likes_count":61957,"limit_end_at":null,"published_at":-28800,"share_msg":"对于学生党来说，宿舍就是第二个家，所以当然要把它布置得舒适、温馨才行！之前小礼君出过许多宿舍神器的攻略，并且深受大家的欢迎，那么今天就再来一发宿舍好物合辑，让你的舍友羡慕去吧~","short_title":"","status":0,"template":"","title":"40件学生党必备宿舍神器","type":"post","updated_at":1473329101,"url":"http://www.liwushuo.com/posts/1045285"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img03.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045243/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/160817/uk1su2jbp.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160817/uk1su2jbp.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328863,"editor_id":1191,"feature_list":[],"hidden_cover_image":false,"id":1045243,"introduction":"对于梳妆收纳，相信每个女生都非常头大。每天匆忙化妆就出门，来不及收拾，晚上回来看到梳妆台散乱无章的瓶瓶罐罐，总是毫无头绪。其实化妆品们也应该来个大扫除！眼影、腮红、化妆刷\u2026\u2026堆在一起用起来非常不方便，而且容易滋生细菌。如何将这些繁杂的化妆品安排得井井有条，甚至变成房间里有设计感的一角？下面跟着小礼君一起来学吧～","labels":[],"liked":false,"likes_count":18260,"limit_end_at":null,"published_at":1471489200,"share_msg":"对于梳妆收纳，相信每个女生都非常头大。每天匆忙化妆就出门，来不及收拾，晚上回来看到梳妆台散乱无章的瓶瓶罐罐，总是毫无头绪。其实化妆品们也应该来个大扫除！眼影、腮红、化妆刷\u2026\u2026堆在一起用起来非常不方便，而且容易滋生细菌。如何将这些繁杂的化妆品安排得井井有条，甚至变成房间里有设计感的一角？下面跟着小礼君一起来学吧～","short_title":"","status":0,"template":"","title":"第48期 | 你不能或缺の梳妆收纳好物","type":"post","updated_at":1471486218,"url":"http://www.liwushuo.com/posts/1045243"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img02.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045067/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160809/ydcj9unb1.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160809/ydcj9unb1.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328855,"editor_id":1147,"feature_list":[],"hidden_cover_image":false,"id":1045067,"introduction":"一只小小的抱枕，虽然并不起眼，但让我们拥有实实在在的安全感。即使孤身一人漂泊在外地，无论是住着出租房抑或学校宿舍，可抱着它带来的心安，总能溢出满满的幸福感，有种归家的暖心感觉。 它会在你疲惫、心累的时候，陪我们躺着，让我们拥在怀里，给我们\u201c依靠\u201d，更像是我们最忠诚的伴侣。所以，这种暖心有爱的小物件小礼君怎能放过，必定要推荐给我的伙伴们啦~","labels":[],"liked":false,"likes_count":25185,"limit_end_at":null,"published_at":1471046400,"share_msg":"一只小小的抱枕，虽然并不起眼，但让我们拥有实实在在的安全感。即使孤身一人漂泊在外地，无论是住着出租房抑或学校宿舍，可抱着它带来的心安，总能溢出满满的幸福感，有种归家的暖心感觉。 它会在你疲惫、心累的时候，陪我们躺着，让我们拥在怀里，给我们\u201c依靠\u201d，更像是我们最忠诚的伴侣。所以，这种暖心有爱的小物件小礼君怎能放过，必定要推荐给我的伙伴们啦~","short_title":"","status":0,"template":"","title":"第47期 | 小抱枕，大幸福","type":"post","updated_at":1470998376,"url":"http://www.liwushuo.com/posts/1045067"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img03.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1044609/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/160715/174ynnm12.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/160715/174ynnm12.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328839,"editor_id":1023,"feature_list":[],"hidden_cover_image":false,"id":1044609,"introduction":"家里面的舒适干净是很重要的，谁都不想要每天回到家以后看到的是四处乱丢的脏衣服、是翻的乱七八糟的杂志还有东一只西一只的鞋子，总之想要有一个舒适的环境，省心方便的收纳装备是必不可少的！对于家里东西很多的宝宝来说，收纳简直就是拯救居住环境的大杀器，看着所有东西都被摆放的井井有条就有一种超级满足的感觉~\\(≧▽≦)/~","labels":[],"liked":false,"likes_count":32725,"limit_end_at":null,"published_at":1468627260,"share_msg":"家里面的舒适干净是很重要的，谁都不想要每天回到家以后看到的是四处乱丢的脏衣服、是翻的乱七八糟的杂志还有东一只西一只的鞋子，总之想要有一个舒适的环境，省心方便的收纳装备是必不可少的！对于家里东西很多的宝宝来说，收纳简直就是拯救居住环境的大杀器，看着所有东西都被摆放的井井有条就有一种超级满足的感觉~\\(≧▽≦)/~","short_title":"收纳","status":0,"template":"","title":"收纳神器在此，\u201c纳\u201d都不是事","type":"post","updated_at":1468665527,"url":"http://www.liwushuo.com/posts/1044609"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160617/hzkkl1ohn.jpg","avatar_webp_url":null,"created_at":1465802857,"id":1,"introduction":"资深买买买达人","nickname":"小礼君"},"column":{"banner_image_url":"http://img02.liwushuo.com/image/160815/v2p80ao8y.jpg-w300","category":"礼物","cover_image_url":"http://img03.liwushuo.com/image/160815/fervz0o5x.jpg-w720","created_at":1471225655,"description":"品质、考究、精心遴选；细节、严格、甄添筛减；处女座强迫症的挑选小组，一份有态度的最佳礼物大赏。","id":94,"order":0,"post_published_at":1476860400,"status":0,"subtitle":"","title":"最佳礼物大赏","updated_at":1477241447},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045035/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/160812/4gsn1vycr.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160812/4gsn1vycr.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328838,"editor_id":1058,"feature_list":[],"hidden_cover_image":false,"id":1045035,"introduction":"每个人肯定都有孤独的时候，也会有无助的时候，也总免不了想要有一个人陪，却恰好智能自己的时候，这个时候也不要\u201c自甘堕落\u201d啦~还有他们陪你嘛！各式各样可爱激萌的抱枕，不管是陪伴你，还是替你陪伴别人，都是很好地选择哦~礼物说星人共同的选择，可爱抱枕TOP来袭！","labels":[],"liked":false,"likes_count":21167,"limit_end_at":null,"published_at":1472612400,"share_msg":"每个人肯定都有孤独的时候，也会有无助的时候，也总免不了想要有一个人陪，却恰好智能自己的时候，这个时候也不要\u201c自甘堕落\u201d啦~还有他们陪你嘛！各式各样可爱激萌的抱枕，不管是陪伴你，还是替你陪伴别人，都是很好地选择哦~礼物说星人共同的选择，可爱抱枕TOP来袭！","short_title":"","status":0,"template":"","title":"想要俘获萌妹柔软心？是时候祭出可爱抱枕了","type":"post","updated_at":1474969907,"url":"http://www.liwushuo.com/posts/1045035"},{"ad_monitors":[],"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"column":{"banner_image_url":"http://img03.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img03.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1044022/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160624/n3dvub7eh.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160624/n3dvub7eh.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476328831,"editor_id":1058,"feature_list":[],"hidden_cover_image":false,"id":1044022,"introduction":"不管是什么性格的女生，不管是什么年龄的女生，他们的心里都会有一个公主的灵魂。虽然也许因为各种原因不能走少女风，或者不喜欢全部都是粉粉的少女感，但总要有一个地方保持和维护住自己的这份少女梦才是对自己真的好嘛。那么，这个地方肯定就是卧室啦~私人安全地带，肯定是释放心底小秘密的绝佳之处！如果你又是恰好不喜欢满房间都是纷纷的少女感的话，那就从这里挑一些小小物件，摆在屋子里，一定会让你的屋子大变样的！","labels":[],"liked":false,"likes_count":27346,"limit_end_at":null,"published_at":1466812800,"share_msg":"不管是什么性格的女生，不管是什么年龄的女生，他们的心里都会有一个公主的灵魂。虽然也许因为各种原因不能走少女风，或者不喜欢全部都是粉粉的少女感，但总要有一个地方保持和维护住自己的这份少女梦才是对自己真的好嘛。那么，这个地方肯定就是卧室啦~私人安全地带，肯定是释放心底小秘密的绝佳之处！如果你又是恰好不喜欢满房间都是纷纷的少女感的话，那就从这里挑一些小小物件，摆在屋子里，一定会让你的屋子大变样的！","short_title":"少女心卧室","status":0,"template":"","title":"第41期 | 小东西大改造，少女宝宝的专属卧室GET√","type":"post","updated_at":1466760770,"url":"http://www.liwushuo.com/posts/1044022"}]
     * paging : {"next_url":"http://api.liwushuo.com/v2/channels/112/items_v2?order_by=now&limit=20&offset=20"}
     */

    private DataBean data;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class DataBean {
        /**
         * next_url : http://api.liwushuo.com/v2/channels/112/items_v2?order_by=now&limit=20&offset=20
         */

        private PagingBean paging;
        /**
         * ad_monitors : []
         * approved_at : null
         * author : {"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","avatar_webp_url":null,"created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"}
         * column : {"banner_image_url":"http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300","category":"美物","cover_image_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"order":0,"post_published_at":1478250000,"status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003}
         * content_type : 1
         * content_url : http://www.liwushuo.com/posts/1046105/content
         * cover_animated_webp_url : null
         * cover_image_url : http://img02.liwushuo.com/image/161014/jwjqsf9ah.jpg-w720
         * cover_webp_url : http://img02.liwushuo.com/image/161014/jwjqsf9ah.jpg?imageView2/2/w/720/q/85/format/webp
         * created_at : 1476944931
         * editor_id : 1018
         * feature_list : []
         * hidden_cover_image : false
         * id : 1046105
         * introduction : 寒冬来临，没有什么比暖暖的被窝更加舒服。在这个床品使用率最高的季节，选择一个适合自己的、优质的床品很有必要。今天小礼君给大家推荐几款温暖床品，如果寒冷只能自己承担，就要学会自己给自己温暖。
         * labels : []
         * liked : false
         * likes_count : 23768
         * limit_end_at : null
         * media_type : 0
         * published_at : 1476867600
         * share_msg : 寒冬来临，没有什么比暖暖的被窝更加舒服。在这个床品使用率最高的季节，选择一个适合自己的、优质的床品很有必要。今天小礼君给大家推荐几款温暖床品，如果寒冷只能自己承担，就要学会自己给自己温暖。#全棉时代：第⑥款商品点击进入，该店铺18-20号全场7折优惠活动，千万不要错过啦#
         * short_title :
         * status : 0
         * template :
         * title : #内有福利#秋冬季节那么好睡，我为什么要起床
         * type : post
         * updated_at : 1476956232
         * url : http://www.liwushuo.com/posts/1046105
         */

        private List<ItemsBean> items;

        public PagingBean getPaging() {
            return paging;
        }

        public void setPaging(PagingBean paging) {
            this.paging = paging;
        }

        public List<ItemsBean> getItems() {
            return items;
        }

        public void setItems(List<ItemsBean> items) {
            this.items = items;
        }

        public static class PagingBean {
            private String next_url;

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }
        }

        public static class ItemsBean {
            private Object approved_at;
            /**
             * avatar_url : http://img01.liwushuo.com/image/160615/sd1vymm55.jpg
             * avatar_webp_url : null
             * created_at : 1465974337
             * id : 10
             * introduction : 家居小物收集爱好者
             * nickname : 叫我小公举
             */

            private AuthorBean author;
            /**
             * banner_image_url : http://img01.liwushuo.com/image/160608/muk9fdsya.jpg-w300
             * category : 美物
             * cover_image_url : http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720
             * created_at : 1462501717
             * description : 僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。
             * id : 14
             * order : 0
             * post_published_at : 1478250000
             * status : 0
             * subtitle :
             * title : 解忧杂货铺
             * updated_at : 1478254003
             */

            private ColumnBean column;
            private int content_type;
            private String content_url;
            private Object cover_animated_webp_url;
            private String cover_image_url;
            private String cover_webp_url;
            private int created_at;
            private int editor_id;
            private boolean hidden_cover_image;
            private int id;
            private String introduction;
            private boolean liked;
            private int likes_count;
            private Object limit_end_at;
            private int media_type;
            private int published_at;
            private String share_msg;
            private String short_title;
            private int status;
            private String template;
            private String title;
            private String type;
            private int updated_at;
            private String url;
            private List<?> ad_monitors;
            private List<?> feature_list;
            private List<?> labels;

            public Object getApproved_at() {
                return approved_at;
            }

            public void setApproved_at(Object approved_at) {
                this.approved_at = approved_at;
            }

            public AuthorBean getAuthor() {
                return author;
            }

            public void setAuthor(AuthorBean author) {
                this.author = author;
            }

            public ColumnBean getColumn() {
                return column;
            }

            public void setColumn(ColumnBean column) {
                this.column = column;
            }

            public int getContent_type() {
                return content_type;
            }

            public void setContent_type(int content_type) {
                this.content_type = content_type;
            }

            public String getContent_url() {
                return content_url;
            }

            public void setContent_url(String content_url) {
                this.content_url = content_url;
            }

            public Object getCover_animated_webp_url() {
                return cover_animated_webp_url;
            }

            public void setCover_animated_webp_url(Object cover_animated_webp_url) {
                this.cover_animated_webp_url = cover_animated_webp_url;
            }

            public String getCover_image_url() {
                return cover_image_url;
            }

            public void setCover_image_url(String cover_image_url) {
                this.cover_image_url = cover_image_url;
            }

            public String getCover_webp_url() {
                return cover_webp_url;
            }

            public void setCover_webp_url(String cover_webp_url) {
                this.cover_webp_url = cover_webp_url;
            }

            public int getCreated_at() {
                return created_at;
            }

            public void setCreated_at(int created_at) {
                this.created_at = created_at;
            }

            public int getEditor_id() {
                return editor_id;
            }

            public void setEditor_id(int editor_id) {
                this.editor_id = editor_id;
            }

            public boolean isHidden_cover_image() {
                return hidden_cover_image;
            }

            public void setHidden_cover_image(boolean hidden_cover_image) {
                this.hidden_cover_image = hidden_cover_image;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getIntroduction() {
                return introduction;
            }

            public void setIntroduction(String introduction) {
                this.introduction = introduction;
            }

            public boolean isLiked() {
                return liked;
            }

            public void setLiked(boolean liked) {
                this.liked = liked;
            }

            public int getLikes_count() {
                return likes_count;
            }

            public void setLikes_count(int likes_count) {
                this.likes_count = likes_count;
            }

            public Object getLimit_end_at() {
                return limit_end_at;
            }

            public void setLimit_end_at(Object limit_end_at) {
                this.limit_end_at = limit_end_at;
            }

            public int getMedia_type() {
                return media_type;
            }

            public void setMedia_type(int media_type) {
                this.media_type = media_type;
            }

            public int getPublished_at() {
                return published_at;
            }

            public void setPublished_at(int published_at) {
                this.published_at = published_at;
            }

            public String getShare_msg() {
                return share_msg;
            }

            public void setShare_msg(String share_msg) {
                this.share_msg = share_msg;
            }

            public String getShort_title() {
                return short_title;
            }

            public void setShort_title(String short_title) {
                this.short_title = short_title;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String getTemplate() {
                return template;
            }

            public void setTemplate(String template) {
                this.template = template;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public int getUpdated_at() {
                return updated_at;
            }

            public void setUpdated_at(int updated_at) {
                this.updated_at = updated_at;
            }

            public String getUrl() {
                return url;
            }

            public void setUrl(String url) {
                this.url = url;
            }

            public List<?> getAd_monitors() {
                return ad_monitors;
            }

            public void setAd_monitors(List<?> ad_monitors) {
                this.ad_monitors = ad_monitors;
            }

            public List<?> getFeature_list() {
                return feature_list;
            }

            public void setFeature_list(List<?> feature_list) {
                this.feature_list = feature_list;
            }

            public List<?> getLabels() {
                return labels;
            }

            public void setLabels(List<?> labels) {
                this.labels = labels;
            }

            public static class AuthorBean {
                private String avatar_url;
                private Object avatar_webp_url;
                private int created_at;
                private int id;
                private String introduction;
                private String nickname;

                public String getAvatar_url() {
                    return avatar_url;
                }

                public void setAvatar_url(String avatar_url) {
                    this.avatar_url = avatar_url;
                }

                public Object getAvatar_webp_url() {
                    return avatar_webp_url;
                }

                public void setAvatar_webp_url(Object avatar_webp_url) {
                    this.avatar_webp_url = avatar_webp_url;
                }

                public int getCreated_at() {
                    return created_at;
                }

                public void setCreated_at(int created_at) {
                    this.created_at = created_at;
                }

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }

                public String getIntroduction() {
                    return introduction;
                }

                public void setIntroduction(String introduction) {
                    this.introduction = introduction;
                }

                public String getNickname() {
                    return nickname;
                }

                public void setNickname(String nickname) {
                    this.nickname = nickname;
                }
            }

            public static class ColumnBean {
                private String banner_image_url;
                private String category;
                private String cover_image_url;
                private int created_at;
                private String description;
                private int id;
                private int order;
                private int post_published_at;
                private int status;
                private String subtitle;
                private String title;
                private int updated_at;

                public String getBanner_image_url() {
                    return banner_image_url;
                }

                public void setBanner_image_url(String banner_image_url) {
                    this.banner_image_url = banner_image_url;
                }

                public String getCategory() {
                    return category;
                }

                public void setCategory(String category) {
                    this.category = category;
                }

                public String getCover_image_url() {
                    return cover_image_url;
                }

                public void setCover_image_url(String cover_image_url) {
                    this.cover_image_url = cover_image_url;
                }

                public int getCreated_at() {
                    return created_at;
                }

                public void setCreated_at(int created_at) {
                    this.created_at = created_at;
                }

                public String getDescription() {
                    return description;
                }

                public void setDescription(String description) {
                    this.description = description;
                }

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }

                public int getOrder() {
                    return order;
                }

                public void setOrder(int order) {
                    this.order = order;
                }

                public int getPost_published_at() {
                    return post_published_at;
                }

                public void setPost_published_at(int post_published_at) {
                    this.post_published_at = post_published_at;
                }

                public int getStatus() {
                    return status;
                }

                public void setStatus(int status) {
                    this.status = status;
                }

                public String getSubtitle() {
                    return subtitle;
                }

                public void setSubtitle(String subtitle) {
                    this.subtitle = subtitle;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public int getUpdated_at() {
                    return updated_at;
                }

                public void setUpdated_at(int updated_at) {
                    this.updated_at = updated_at;
                }
            }
        }
    }
}
