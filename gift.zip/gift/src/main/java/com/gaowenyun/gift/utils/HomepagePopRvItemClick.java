package com.gaowenyun.gift.utils;

/**
 *
 */
public interface HomepagePopRvItemClick {
    void OnPopRvItemClickListener(int position, String string);
}
