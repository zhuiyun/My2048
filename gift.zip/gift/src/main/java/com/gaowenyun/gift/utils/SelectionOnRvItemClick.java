package com.gaowenyun.gift.utils;


import com.gaowenyun.gift.model.bean.SelectionRvBean;

/**
 *
 */
public interface SelectionOnRvItemClick {
    void onRvItemClickListener(int positon, SelectionRvBean.DataBean.SecondaryBannersBean data);
}
