package com.gaowenyun.gift.utils;

/**
 *
 */
public interface GiftOnRvItemClick<T> {
    void onRvItemClickListener(int positon, T t);
}
