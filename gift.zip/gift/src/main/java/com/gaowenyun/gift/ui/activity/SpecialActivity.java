package com.gaowenyun.gift.ui.activity;


import com.gaowenyun.gift.R;

/**
 *
 */
public class SpecialActivity extends AbsBaseActivity {
    @Override
    protected int setLayout() {
        return R.layout.activity_special;
    }

    @Override
    protected void initViews() {

    }

    @Override
    protected void initDatas() {

    }
}
