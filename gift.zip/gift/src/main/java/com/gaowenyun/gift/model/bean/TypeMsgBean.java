package com.gaowenyun.gift.model.bean;


//                            _ooOoo_  
//                           o8888888o  
//                           88" . "88  
//                           (| -_- |)  
//                            O\ = /O  
//                        ____/`---'\____  
//                      .   ' \\| |// `.  
//                       / \\||| : |||// \  
//                     / _||||| -:- |||||- \  
//                       | | \\\ - /// | |  
//                     | \_| ''\---/'' | |  
//                      \ .-\__ `-` ___/-. /  
//                   ___`. .' /--.--\ `. . __  
//                ."" '< `.___\_<|>_/___.' >'"".  
//               | | : `- \`.;`\ _ /`;.`/ - ` : | |  
//                 \ \ `-. \_ __\ /__ _/ .-` / /  
//         ======`-.____`-.___\_____/___.-`____.-'======  
//                            `=---='  
//  
//         .............................................  
//                  佛祖镇楼                  BUG辟易  
//          佛曰:  
//                  写字楼里写字间，写字间里程序员；  
//                  程序人员写程序，又拿程序换酒钱。  
//                  酒醒只在网上坐，酒醉还来网下眠；  
//                  酒醉酒醒日复日，网上网下年复年。  
//                  但愿老死电脑间，不愿鞠躬老板前；  
//                  奔驰宝马贵者趣，公交自行程序员。  
//                  别人笑我忒疯癫，我笑自己命太贱；  
//                  不见满街漂亮妹，哪个归得程序员？  


import java.util.List;

/**
 * Created by Administrator on 2016/11/5 0005.
 */
public class TypeMsgBean {


    /**
     * code : 200
     * data : {"banner_image_url":"http://img02.liwushuo.com/image/160608/muk9fdsya.jpg-w300","banner_webp_url":"http://img02.liwushuo.com/image/160608/muk9fdsya.jpg?imageView2/2/w/300/q/85/format/webp","category":"美物","cover_image_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160713/1p98sh06h.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1462501717,"description":"僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。","id":14,"likes_count":2144940,"order":0,"paging":{"next_url":"http://api.liwushuo.com/v2/columns/14?limit=20&offset=20"},"post_published_at":1478250000,"posts":[{"ad_monitors":[],"approved_at":1477994916,"author":{"avatar_url":"http://img01.liwushuo.com/image/160617/hzkkl1ohn.jpg","created_at":1465802857,"id":1,"introduction":"资深买买买达人","nickname":"小礼君"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046387/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161101/65x0un3ug.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161101/65x0un3ug.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1478250000,"editor_id":1018,"feature_list":[],"id":1046387,"introduction":"老实说，实在是不喜欢冬天，因为真心太冷了。人都开始变懒了，虽然平时也不是很勤快吧，但是现在更加懒得动了，周末要是有朋友约的话，大概也只能拒绝了，我只想宅在家里，静静的，披着我的懒人毯子，然后开始冬眠。","label_ids":[],"liked":false,"likes_count":11563,"limit_end_at":null,"media_type":0,"published_at":1478250000,"share_msg":"老实说，实在是不喜欢冬天，因为真心太冷了。人都开始变懒了，虽然平时也不是很勤快吧，但是现在更加懒得动了，周末要是有朋友约的话，大概也只能拒绝了，我只想宅在家里，静静的，披着我的懒人毯子，然后开始冬眠。","short_title":"","status":0,"template":"","title":"懒人冬眠时间开始了，毯子准备好了吗？","updated_at":1478167445,"url":"http://www.liwushuo.com/posts/1046387"},{"ad_monitors":[],"approved_at":1477964461,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046362/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/161101/kjmyw1zvm.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/161101/kjmyw1zvm.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1478077200,"editor_id":1018,"feature_list":[],"id":1046362,"introduction":"自从入秋以来，一直都处于一个干燥的环境当中，嘴巴干、手干！而且现在脱衣服的时候都会有霹雳巴拉的感觉了，所有的干燥原因就是一点，你需要补水啦！要记得每晚上敷敷补水面膜，然后开个加湿器，重要的是，要记得多多喝温水哦。","label_ids":[],"liked":false,"likes_count":10306,"limit_end_at":null,"media_type":0,"published_at":1478077200,"share_msg":"自从入秋以来，一直都处于一个干燥的环境当中，嘴巴干、手干！而且现在脱衣服的时候都会有霹雳巴拉的感觉了，所有的干燥原因就是一点，你需要补水啦！要记得每晚上敷敷补水面膜，然后开个加湿器，重要的是，要记得多多喝温水哦。","short_title":"","status":0,"template":"","title":"拯救不爱喝水星人，只需一个颜高水杯","updated_at":1478073918,"url":"http://www.liwushuo.com/posts/1046362"},{"ad_monitors":[],"approved_at":1476960599,"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046197/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/161020/5k59lzw0y.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/161020/5k59lzw0y.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1477645200,"editor_id":1018,"feature_list":[],"id":1046197,"introduction":"香薰，追根溯源，本是一种古老的治疗及美容方法，从古埃及艳后用玫瑰铺满寝宫，到我国唐代杨贵妃用鲜花浸泡沐浴，都可窥见一斑。今天小公举就要给大家推荐几款芬芳的香薰精油，送给你关爱的Ta，愿Ta在在芳香间收获好心情。","label_ids":[],"liked":false,"likes_count":13636,"limit_end_at":null,"media_type":0,"published_at":1477645200,"share_msg":"香薰，追根溯源，本是一种古老的治疗及美容方法，从古埃及艳后用玫瑰铺满寝宫，到我国唐代杨贵妃用鲜花浸泡沐浴，都可窥见一斑。今天小公举就要给大家推荐几款芬芳的香薰精油，送给你关爱的Ta，愿Ta在在芳香间收获好心情。","short_title":"","status":0,"template":"","title":"香薰是生活调味剂，少女的家就要香香哒","updated_at":1477561566,"url":"http://www.liwushuo.com/posts/1046197"},{"ad_monitors":[],"approved_at":1476869207,"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046178/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/161019/l645k1ld1.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/161019/l645k1ld1.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1477472400,"editor_id":1018,"feature_list":[],"id":1046178,"introduction":"咦，为什么现在是秋天却感觉冷冷哒呢？说好的秋老虎，怎么欺骗我感情呢！要不是现在拥有了这些御寒神器，我估计都要冷到心凉啦，如果你们现在也感觉到寒冷的话，快码住这些神器啊，宅家看剧超暖哒，这个冬天一定要暖暖的过。","label_ids":[],"liked":false,"likes_count":10859,"limit_end_at":null,"media_type":0,"published_at":1477472400,"share_msg":"咦，为什么现在是秋天却感觉冷冷哒呢？说好的秋老虎，怎么欺骗我感情呢！要不是现在拥有了这些御寒神器，我估计都要冷到心凉啦，如果你们现在也感觉到寒冷的话，快码住这些神器啊，宅家看剧超暖哒，这个冬天一定要暖暖的过。","short_title":"","status":0,"template":"","title":"有些事暖男不一定能做到，可是他们能啊","updated_at":1477389191,"url":"http://www.liwushuo.com/posts/1046178"},{"ad_monitors":[],"approved_at":1476848795,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046154/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161018/9o53gu817.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161018/9o53gu817.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1477299600,"editor_id":1018,"feature_list":[],"id":1046154,"introduction":" 今天的餐具，都是很极简的，好看的我都舍不得分享呢，小公举真是淘的肩膀都酸疼了，（快来给我捏捏吧T .T）用这么好看的餐盘吃饭，你还能没有食欲吗！？你们可一定不要为了减肥，而绝食，这样真的很不健康，饭一定要吃的，不然小礼君会不开心的~所以请答应我，一个人也要好好吃饭好吗？","label_ids":[],"liked":false,"likes_count":10118,"limit_end_at":null,"media_type":0,"published_at":1477299600,"share_msg":"今天的餐具，都是很极简的，好看的我都舍不得分享呢，小公举真是淘的肩膀都酸疼了，（快来给我捏捏吧T .T）用这么好看的餐盘吃饭，你还能没有食欲吗！？你们可一定不要为了减肥，而绝食，这样真的很不健康，饭一定要吃的，不然小礼君会不开心的~所以请答应我，一个人也要好好吃饭好吗？","short_title":"","status":0,"template":"","title":"用这么好看的餐盘吃饭，吃饭都香香哒！","updated_at":1477241289,"url":"http://www.liwushuo.com/posts/1046154"},{"ad_monitors":[],"approved_at":1476848879,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046141/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161017/z01l683kk.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161017/z01l683kk.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1477213200,"editor_id":1018,"feature_list":[],"id":1046141,"introduction":"宿舍就像是我们的第二个家，我们有什么理由不好好爱它呢？小礼君上学的时候，有时候看到别的同学把宿舍打扮的很漂亮温馨，就会很羡慕。你会不会也喜欢那种井井有条的宿舍环境呢？小礼君今天就帮你一起打造一下你的宿舍，让它干净整洁有品质！","label_ids":[],"liked":false,"likes_count":13369,"limit_end_at":null,"media_type":0,"published_at":1477213200,"share_msg":"宿舍就像是我们的第二个家，我们有什么理由不好好爱它呢？小礼君上学的时候，有时候看到别的同学把宿舍打扮的很漂亮温馨，就会很羡慕。你会不会也喜欢那种井井有条的宿舍环境呢？小礼君今天就帮你一起打造一下你的宿舍，让它干净整洁有品质！","short_title":"","status":0,"template":"","title":"在校园寻找归属感，寝室应该如家般温馨","updated_at":1477062249,"url":"http://www.liwushuo.com/posts/1046141"},{"ad_monitors":[],"approved_at":1476687258,"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046117/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161013/nahv392s0.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161013/nahv392s0.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1477040400,"editor_id":1018,"feature_list":[],"id":1046117,"introduction":" 天气越来越冷，空气越来越干了，每次脱下毛衣的时候都能听到噼里啪啦的静电声音，而且衣服上总会粘着一些灰尘，让衣服看起来完全没有型了呢。所以如果你拥有了以下这10款秋冬季节必备的神器的话，就能够帮助你解决不少问题哦。","label_ids":[],"liked":false,"likes_count":16593,"limit_end_at":null,"media_type":0,"published_at":1477040400,"share_msg":"天气越来越冷，空气越来越干了，每次脱下毛衣的时候都能听到噼里啪啦的静电声音，而且衣服上总会粘着一些灰尘，让衣服看起来完全没有型了呢。所以如果你拥有了以下这10款秋冬季节必备的神器的话，就能够帮助你解决不少问题哦。","short_title":"","status":0,"template":"","title":"#中奖名单#10款秋季必备神器，你还差哪几样？","updated_at":1477103582,"url":"http://www.liwushuo.com/posts/1046117"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046105/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161014/jwjqsf9ah.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161014/jwjqsf9ah.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476867600,"editor_id":1018,"feature_list":[],"id":1046105,"introduction":"寒冬来临，没有什么比暖暖的被窝更加舒服。在这个床品使用率最高的季节，选择一个适合自己的、优质的床品很有必要。今天小礼君给大家推荐几款温暖床品，如果寒冷只能自己承担，就要学会自己给自己温暖。","label_ids":[],"liked":false,"likes_count":23733,"limit_end_at":null,"media_type":0,"published_at":1476867600,"share_msg":"寒冬来临，没有什么比暖暖的被窝更加舒服。在这个床品使用率最高的季节，选择一个适合自己的、优质的床品很有必要。今天小礼君给大家推荐几款温暖床品，如果寒冷只能自己承担，就要学会自己给自己温暖。#全棉时代：第⑥款商品点击进入，该店铺18-20号全场7折优惠活动，千万不要错过啦#","short_title":"","status":0,"template":"","title":"#内有福利#秋冬季节那么好睡，我为什么要起床","updated_at":1476956232,"url":"http://www.liwushuo.com/posts/1046105"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046069/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161010/fzdaf0wzz.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161010/fzdaf0wzz.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476694800,"editor_id":1018,"feature_list":[],"id":1046069,"introduction":" 每次去路过家居店就想进去逛荡一圈，看到慵懒的沙发就想一屁股坐在上面，把自己种在上面，就这么静静的待一下午，懒人沙发，没有骨架，随意造型，可以把整个人窝在里面享受慵懒的私人空间。下面这10款懒人沙发可别错过了哟。","label_ids":[],"liked":false,"likes_count":21073,"limit_end_at":null,"media_type":null,"published_at":1476694800,"share_msg":"每次去路过家居店就想进去逛荡一圈，看到慵懒的沙发就想一屁股坐在上面，有一种想把自己种在上面的冲动，就这么静静的待一下午。懒人沙发呢，没有骨架，随意造型，可以把整个人窝在里面享受慵懒的私人空间。下面这10款懒人沙发可别错过了哟。","short_title":"","status":0,"template":"","title":"舒舒服服宅在家，懒人沙发才是标配","updated_at":1476669720,"url":"http://www.liwushuo.com/posts/1046069"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"一个家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046083/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161011/d59c7h61t.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161011/d59c7h61t.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476608400,"editor_id":1018,"feature_list":[],"id":1046083,"introduction":"现在天气变得凉凉的了，你是否还光着脚丫呢，小心不要着凉了哟，毕竟寒从脚起，所以保暖脚丫是关键，小礼君保证你会爱上今天这篇攻略，通通都是我为你们选的少女款哟，而且还超级舒适的呢~不冻脚丫的秘诀就在这里，小礼君都入手了，你还不跟上吗？","label_ids":[],"liked":false,"likes_count":23058,"limit_end_at":null,"media_type":0,"published_at":1476608400,"share_msg":"现在天气变得凉凉的了，你是否还光着脚丫呢，小心不要着凉了哟，毕竟寒从脚起，所以保暖脚丫是关键，小礼君保证你会爱上今天这篇攻略，通通都是我为你们选的少女款哟，而且还超级舒适的呢~不冻脚丫的秘诀就在这里，小礼君都入手了，你还不跟上吗？","short_title":"","status":0,"template":"","title":"光脚丫的季节已经过去，护脚的事情交给它来做","updated_at":1476673180,"url":"http://www.liwushuo.com/posts/1046083"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046049/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/161009/5il44zbkz.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/161009/5il44zbkz.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476349200,"editor_id":1018,"feature_list":[],"id":1046049,"introduction":"走进一间都是关于大自然的家里，打开门的那瞬间你所看到的都是自然之境时，那会有多舒服啊。尽管在外面遇到了多少的压力与不愉快，只要进了家里坏心情通通都烟消云散了。如果恰好你也喜欢这种自然风格，那么停下脚步来花几分钟来欣赏这些美物给你带来的好心情吧。","label_ids":[],"liked":false,"likes_count":9756,"limit_end_at":null,"published_at":1476328963,"share_msg":"走进一间都是关于大自然的家里，打开门的那瞬间你所看到的都是自然之境时，那会有多舒服啊。尽管在外面遇到了多少的压力与不愉快，只要进了家里坏心情通通都烟消云散了。如果恰好你也喜欢这种自然风格，那么停下脚步来花几分钟来欣赏这些美物给你带来的好心情吧。","short_title":"","status":0,"template":"","title":"回归\u201c大自然\u201d本色，还你一个清新自然的家","updated_at":1476328963,"url":"http://www.liwushuo.com/posts/1046049"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045965/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/161008/40lswrpaw.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/161008/40lswrpaw.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476176400,"editor_id":1191,"feature_list":[],"id":1045965,"introduction":"在干巴巴的秋冬季节，御寒保暖更要保湿。在相对封闭的空间里，无论是家庭还是公司，空气加湿器担当着营造舒适环境的重担。","label_ids":[],"liked":false,"likes_count":18961,"limit_end_at":null,"media_type":0,"published_at":1476176400,"share_msg":"在干巴巴的秋冬季节，御寒保暖更要保湿。在相对封闭的空间里，无论是家庭还是公司，空气加湿器担当着营造舒适环境的重担。","short_title":"","status":0,"template":"","title":"对抗干巴巴的秋冬季，你还需要一个强大的加湿器","updated_at":1476105384,"url":"http://www.liwushuo.com/posts/1045965"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045942/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161008/ixy8kvvv6.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161008/ixy8kvvv6.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1475917200,"editor_id":1191,"feature_list":[],"id":1045942,"introduction":"虽然小礼君已经离开校园数载，但作为一名文具控，收藏的文具们可一点儿都不比当学生的时候少，so，今天就来晒晒小礼君自己收藏的萌系文具，不知道有没有同道中人呢？现在的文具除了实用功能以外，还有一些超级治愈的萌物。?","label_ids":[],"liked":false,"likes_count":20982,"limit_end_at":null,"published_at":1475917200,"share_msg":"虽然小礼君已经离开校园数载，但作为一名文具控，收藏的文具们可一点儿都不比当学生的时候少，so，今天就来晒晒小礼君自己收藏的萌系文具，不知道有没有同道中人呢？现在的文具除了实用功能以外，还是超级治愈的萌物。?","short_title":"","status":0,"template":"","title":"可爱到犯规的文具们 (๑´ω`๑)","updated_at":1475916911,"url":"http://www.liwushuo.com/posts/1045942"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045892/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160928/pqeqmqarr.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160928/pqeqmqarr.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1475744400,"editor_id":1191,"feature_list":[],"id":1045892,"introduction":"冯唐说过， 我要用尽我的万种风情， 让你在将来任何不和我在一起的时候， 内心无法安宁。","label_ids":[],"liked":false,"likes_count":15494,"limit_end_at":null,"published_at":1475744400,"share_msg":"冯唐说过，","short_title":"","status":0,"template":"","title":"给留白的空间多一点想象","updated_at":1475325155,"url":"http://www.liwushuo.com/posts/1045892"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045880/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160928/gkc136q43.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160928/gkc136q43.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1475571600,"editor_id":1191,"feature_list":[],"id":1045880,"introduction":"吾日三省吾身：早饭吃啥，午饭吃啥，晚饭吃啥。","label_ids":[],"liked":false,"likes_count":18553,"limit_end_at":null,"published_at":1475571600,"share_msg":"吾日三省吾身：早饭吃啥，午饭吃啥，晚饭吃啥。","short_title":"","status":0,"template":"","title":"只有好看的便当盒，才能勾起我带饭的欲望","updated_at":1475326847,"url":"http://www.liwushuo.com/posts/1045880"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045864/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/160928/cba2a35g2.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160928/cba2a35g2.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1475312400,"editor_id":1191,"feature_list":[],"id":1045864,"introduction":"你一定也遇到过这样的问题：一时冲动买买买，然后就再也没有用过的东西想着\u201c总有一天会用到\u201d，结果积了一整年的灰好不容易花时间收拾了，结果过几天又乱了。这样不停死循环的人生！怎么破？","label_ids":[],"liked":false,"likes_count":20556,"limit_end_at":null,"published_at":1475312400,"share_msg":"你一定也遇到过这样的问题：一时冲动买买买，然后就再也没有用过的东西想着\u201c总有一天会用到\u201d，结果积了一整年的灰好不容易花时间收拾了，结果过几天又乱了。这样不停死循环的人生！怎么破？","short_title":"","status":0,"template":"","title":"原谅我一生放荡不羁东西多，还好我是个收纳狂魔","updated_at":1475229585,"url":"http://www.liwushuo.com/posts/1045864"},{"ad_monitors":[],"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":2,"content_url":"http://www.liwushuo.com/posts/1045828/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/160928/i897lm3ay.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/160928/i897lm3ay.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1475139600,"editor_id":1191,"feature_list":[9],"id":1045828,"introduction":"无论是阳关充裕的沙滩，还是休闲惬意的午后，无论是温馨优雅的果园，还是神秘奇异的丛林，不管你的假日打算在哪里度过，小礼君都要教你如何在家假装度假，只需几件小物品，立马让你在家也能享受假日风情～?","label_ids":[],"liked":false,"likes_count":15680,"limit_end_at":null,"published_at":1475139600,"share_msg":"无论是阳关充裕的沙滩，还是休闲惬意的午后，无论是温馨优雅的果园，还是神秘奇异的丛林，不管你的假日打算在哪里度过，小礼君都要教你如何在家假装度假，只需几件小物品，立马让你在家也能享受假日风情～?","short_title":"","status":0,"template":"","title":"国庆不看人海，我有在家宅出假日风情的特殊技巧√","updated_at":1475062066,"url":"http://www.liwushuo.com/posts/1045828"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045794/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160927/sap4tzcix.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160927/sap4tzcix.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1474966800,"editor_id":1191,"feature_list":[],"id":1045794,"introduction":"\u201c若只是吃，可以像远古时代的人们那样把食物盛在叶片上吃。但若想达到更高层次，就有必要选择容器。食器与料理，永远有着无法分离的密切关系，两者的关系可说如同夫妻一般。\u201d\u2014\u2014北大路鲁山人在那篇著名《食器是料理的衣裳》中如此写道。","label_ids":[],"liked":false,"likes_count":20344,"limit_end_at":null,"published_at":1474966800,"share_msg":"\u201c若只是吃，可以像远古时代的人们那样把食物盛在叶片上吃。但若想达到更高层次，就有必要选择容器。食器与料理，永远有着无法分离的密切关系，两者的关系可说如同夫妻一般。\u201d\u2014\u2014北大路鲁山人在那篇著名《食器是料理的衣裳》中如此写道。","short_title":"","status":0,"template":"","title":"丢你一只下饭的碗，独享碗盏里的小确幸","updated_at":1475029290,"url":"http://www.liwushuo.com/posts/1045794"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":2,"content_url":"http://www.liwushuo.com/posts/1045775/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160928/f4qow5eqs.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160928/f4qow5eqs.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1474707600,"editor_id":1191,"feature_list":[1,3,9],"id":1045775,"introduction":"最近的天气真是干得教人一天喝八杯水都觉得不够。为了让自己多喝一点水，只能换着法儿地泡不同的东西喝。 柠檬、菊花、铁观音喝了一圈已经不能再爱了，一到下午三四点就想点一杯下午茶喝喝，不知道乃们是不是也一样？","label_ids":[],"liked":false,"likes_count":21760,"limit_end_at":null,"published_at":1474707600,"share_msg":"最近的天气真是干得教人一天喝八杯水都觉得不够。为了让自己多喝一点水，只能换着法儿地泡不同的东西喝。 柠檬、菊花、铁观音喝了一圈已经不能再爱了，一到下午三四点就想点一杯下午茶喝喝，不知道乃们是不是也一样？","short_title":"","status":0,"template":"","title":"第64期｜秋风凛凛，你需要一杯体贴的热茶","updated_at":1475025393,"url":"http://www.liwushuo.com/posts/1045775"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045740/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160928/uxmswag0q.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160928/uxmswag0q.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1474534800,"editor_id":1191,"feature_list":[],"id":1045740,"introduction":"每年的七夕或情人节，多数人都会选择和TA外出用餐，但是要浪漫，何仅限于这些被定义出来的节日呢？在家备上营造氛围的物品，什么时候是情人节，自己说了算。","label_ids":[],"liked":false,"likes_count":12446,"limit_end_at":null,"published_at":1474534800,"share_msg":"每年的七夕或情人节，多数人都会选择和TA外出用餐，但是要浪漫，何仅限于这些被定义出来的节日呢？在家备上营造氛围的物品，什么时候是情人节，自己说了算。","short_title":"","status":0,"template":"","title":"第63期｜在家准备两人餐都需要什么","updated_at":1475024986,"url":"http://www.liwushuo.com/posts/1045740"}],"share_url":"http://hawaii.liwushuo.com/column/14","status":0,"subtitle":"","title":"解忧杂货铺","updated_at":1478254003}
     * message : OK
     */

    private int code;
    /**
     * banner_image_url : http://img02.liwushuo.com/image/160608/muk9fdsya.jpg-w300
     * banner_webp_url : http://img02.liwushuo.com/image/160608/muk9fdsya.jpg?imageView2/2/w/300/q/85/format/webp
     * category : 美物
     * cover_image_url : http://img01.liwushuo.com/image/160713/1p98sh06h.jpg-w720
     * cover_webp_url : http://img01.liwushuo.com/image/160713/1p98sh06h.jpg?imageView2/2/w/720/q/85/format/webp
     * created_at : 1462501717
     * description : 僻静的街角有一家杂货铺，或许你带着忧愁走进店中，但不期而遇的小物却让你展露欢颜。
     * id : 14
     * likes_count : 2144940
     * order : 0
     * paging : {"next_url":"http://api.liwushuo.com/v2/columns/14?limit=20&offset=20"}
     * post_published_at : 1478250000
     * posts : [{"ad_monitors":[],"approved_at":1477994916,"author":{"avatar_url":"http://img01.liwushuo.com/image/160617/hzkkl1ohn.jpg","created_at":1465802857,"id":1,"introduction":"资深买买买达人","nickname":"小礼君"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046387/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161101/65x0un3ug.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161101/65x0un3ug.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1478250000,"editor_id":1018,"feature_list":[],"id":1046387,"introduction":"老实说，实在是不喜欢冬天，因为真心太冷了。人都开始变懒了，虽然平时也不是很勤快吧，但是现在更加懒得动了，周末要是有朋友约的话，大概也只能拒绝了，我只想宅在家里，静静的，披着我的懒人毯子，然后开始冬眠。","label_ids":[],"liked":false,"likes_count":11563,"limit_end_at":null,"media_type":0,"published_at":1478250000,"share_msg":"老实说，实在是不喜欢冬天，因为真心太冷了。人都开始变懒了，虽然平时也不是很勤快吧，但是现在更加懒得动了，周末要是有朋友约的话，大概也只能拒绝了，我只想宅在家里，静静的，披着我的懒人毯子，然后开始冬眠。","short_title":"","status":0,"template":"","title":"懒人冬眠时间开始了，毯子准备好了吗？","updated_at":1478167445,"url":"http://www.liwushuo.com/posts/1046387"},{"ad_monitors":[],"approved_at":1477964461,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046362/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/161101/kjmyw1zvm.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/161101/kjmyw1zvm.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1478077200,"editor_id":1018,"feature_list":[],"id":1046362,"introduction":"自从入秋以来，一直都处于一个干燥的环境当中，嘴巴干、手干！而且现在脱衣服的时候都会有霹雳巴拉的感觉了，所有的干燥原因就是一点，你需要补水啦！要记得每晚上敷敷补水面膜，然后开个加湿器，重要的是，要记得多多喝温水哦。","label_ids":[],"liked":false,"likes_count":10306,"limit_end_at":null,"media_type":0,"published_at":1478077200,"share_msg":"自从入秋以来，一直都处于一个干燥的环境当中，嘴巴干、手干！而且现在脱衣服的时候都会有霹雳巴拉的感觉了，所有的干燥原因就是一点，你需要补水啦！要记得每晚上敷敷补水面膜，然后开个加湿器，重要的是，要记得多多喝温水哦。","short_title":"","status":0,"template":"","title":"拯救不爱喝水星人，只需一个颜高水杯","updated_at":1478073918,"url":"http://www.liwushuo.com/posts/1046362"},{"ad_monitors":[],"approved_at":1476960599,"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046197/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/161020/5k59lzw0y.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/161020/5k59lzw0y.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1477645200,"editor_id":1018,"feature_list":[],"id":1046197,"introduction":"香薰，追根溯源，本是一种古老的治疗及美容方法，从古埃及艳后用玫瑰铺满寝宫，到我国唐代杨贵妃用鲜花浸泡沐浴，都可窥见一斑。今天小公举就要给大家推荐几款芬芳的香薰精油，送给你关爱的Ta，愿Ta在在芳香间收获好心情。","label_ids":[],"liked":false,"likes_count":13636,"limit_end_at":null,"media_type":0,"published_at":1477645200,"share_msg":"香薰，追根溯源，本是一种古老的治疗及美容方法，从古埃及艳后用玫瑰铺满寝宫，到我国唐代杨贵妃用鲜花浸泡沐浴，都可窥见一斑。今天小公举就要给大家推荐几款芬芳的香薰精油，送给你关爱的Ta，愿Ta在在芳香间收获好心情。","short_title":"","status":0,"template":"","title":"香薰是生活调味剂，少女的家就要香香哒","updated_at":1477561566,"url":"http://www.liwushuo.com/posts/1046197"},{"ad_monitors":[],"approved_at":1476869207,"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046178/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/161019/l645k1ld1.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/161019/l645k1ld1.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1477472400,"editor_id":1018,"feature_list":[],"id":1046178,"introduction":"咦，为什么现在是秋天却感觉冷冷哒呢？说好的秋老虎，怎么欺骗我感情呢！要不是现在拥有了这些御寒神器，我估计都要冷到心凉啦，如果你们现在也感觉到寒冷的话，快码住这些神器啊，宅家看剧超暖哒，这个冬天一定要暖暖的过。","label_ids":[],"liked":false,"likes_count":10859,"limit_end_at":null,"media_type":0,"published_at":1477472400,"share_msg":"咦，为什么现在是秋天却感觉冷冷哒呢？说好的秋老虎，怎么欺骗我感情呢！要不是现在拥有了这些御寒神器，我估计都要冷到心凉啦，如果你们现在也感觉到寒冷的话，快码住这些神器啊，宅家看剧超暖哒，这个冬天一定要暖暖的过。","short_title":"","status":0,"template":"","title":"有些事暖男不一定能做到，可是他们能啊","updated_at":1477389191,"url":"http://www.liwushuo.com/posts/1046178"},{"ad_monitors":[],"approved_at":1476848795,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046154/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161018/9o53gu817.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161018/9o53gu817.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1477299600,"editor_id":1018,"feature_list":[],"id":1046154,"introduction":" 今天的餐具，都是很极简的，好看的我都舍不得分享呢，小公举真是淘的肩膀都酸疼了，（快来给我捏捏吧T .T）用这么好看的餐盘吃饭，你还能没有食欲吗！？你们可一定不要为了减肥，而绝食，这样真的很不健康，饭一定要吃的，不然小礼君会不开心的~所以请答应我，一个人也要好好吃饭好吗？","label_ids":[],"liked":false,"likes_count":10118,"limit_end_at":null,"media_type":0,"published_at":1477299600,"share_msg":"今天的餐具，都是很极简的，好看的我都舍不得分享呢，小公举真是淘的肩膀都酸疼了，（快来给我捏捏吧T .T）用这么好看的餐盘吃饭，你还能没有食欲吗！？你们可一定不要为了减肥，而绝食，这样真的很不健康，饭一定要吃的，不然小礼君会不开心的~所以请答应我，一个人也要好好吃饭好吗？","short_title":"","status":0,"template":"","title":"用这么好看的餐盘吃饭，吃饭都香香哒！","updated_at":1477241289,"url":"http://www.liwushuo.com/posts/1046154"},{"ad_monitors":[],"approved_at":1476848879,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046141/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161017/z01l683kk.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161017/z01l683kk.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1477213200,"editor_id":1018,"feature_list":[],"id":1046141,"introduction":"宿舍就像是我们的第二个家，我们有什么理由不好好爱它呢？小礼君上学的时候，有时候看到别的同学把宿舍打扮的很漂亮温馨，就会很羡慕。你会不会也喜欢那种井井有条的宿舍环境呢？小礼君今天就帮你一起打造一下你的宿舍，让它干净整洁有品质！","label_ids":[],"liked":false,"likes_count":13369,"limit_end_at":null,"media_type":0,"published_at":1477213200,"share_msg":"宿舍就像是我们的第二个家，我们有什么理由不好好爱它呢？小礼君上学的时候，有时候看到别的同学把宿舍打扮的很漂亮温馨，就会很羡慕。你会不会也喜欢那种井井有条的宿舍环境呢？小礼君今天就帮你一起打造一下你的宿舍，让它干净整洁有品质！","short_title":"","status":0,"template":"","title":"在校园寻找归属感，寝室应该如家般温馨","updated_at":1477062249,"url":"http://www.liwushuo.com/posts/1046141"},{"ad_monitors":[],"approved_at":1476687258,"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046117/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161013/nahv392s0.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161013/nahv392s0.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1477040400,"editor_id":1018,"feature_list":[],"id":1046117,"introduction":" 天气越来越冷，空气越来越干了，每次脱下毛衣的时候都能听到噼里啪啦的静电声音，而且衣服上总会粘着一些灰尘，让衣服看起来完全没有型了呢。所以如果你拥有了以下这10款秋冬季节必备的神器的话，就能够帮助你解决不少问题哦。","label_ids":[],"liked":false,"likes_count":16593,"limit_end_at":null,"media_type":0,"published_at":1477040400,"share_msg":"天气越来越冷，空气越来越干了，每次脱下毛衣的时候都能听到噼里啪啦的静电声音，而且衣服上总会粘着一些灰尘，让衣服看起来完全没有型了呢。所以如果你拥有了以下这10款秋冬季节必备的神器的话，就能够帮助你解决不少问题哦。","short_title":"","status":0,"template":"","title":"#中奖名单#10款秋季必备神器，你还差哪几样？","updated_at":1477103582,"url":"http://www.liwushuo.com/posts/1046117"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046105/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161014/jwjqsf9ah.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161014/jwjqsf9ah.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476867600,"editor_id":1018,"feature_list":[],"id":1046105,"introduction":"寒冬来临，没有什么比暖暖的被窝更加舒服。在这个床品使用率最高的季节，选择一个适合自己的、优质的床品很有必要。今天小礼君给大家推荐几款温暖床品，如果寒冷只能自己承担，就要学会自己给自己温暖。","label_ids":[],"liked":false,"likes_count":23733,"limit_end_at":null,"media_type":0,"published_at":1476867600,"share_msg":"寒冬来临，没有什么比暖暖的被窝更加舒服。在这个床品使用率最高的季节，选择一个适合自己的、优质的床品很有必要。今天小礼君给大家推荐几款温暖床品，如果寒冷只能自己承担，就要学会自己给自己温暖。#全棉时代：第⑥款商品点击进入，该店铺18-20号全场7折优惠活动，千万不要错过啦#","short_title":"","status":0,"template":"","title":"#内有福利#秋冬季节那么好睡，我为什么要起床","updated_at":1476956232,"url":"http://www.liwushuo.com/posts/1046105"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046069/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161010/fzdaf0wzz.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161010/fzdaf0wzz.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476694800,"editor_id":1018,"feature_list":[],"id":1046069,"introduction":" 每次去路过家居店就想进去逛荡一圈，看到慵懒的沙发就想一屁股坐在上面，把自己种在上面，就这么静静的待一下午，懒人沙发，没有骨架，随意造型，可以把整个人窝在里面享受慵懒的私人空间。下面这10款懒人沙发可别错过了哟。","label_ids":[],"liked":false,"likes_count":21073,"limit_end_at":null,"media_type":null,"published_at":1476694800,"share_msg":"每次去路过家居店就想进去逛荡一圈，看到慵懒的沙发就想一屁股坐在上面，有一种想把自己种在上面的冲动，就这么静静的待一下午。懒人沙发呢，没有骨架，随意造型，可以把整个人窝在里面享受慵懒的私人空间。下面这10款懒人沙发可别错过了哟。","short_title":"","status":0,"template":"","title":"舒舒服服宅在家，懒人沙发才是标配","updated_at":1476669720,"url":"http://www.liwushuo.com/posts/1046069"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"一个家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046083/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161011/d59c7h61t.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161011/d59c7h61t.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476608400,"editor_id":1018,"feature_list":[],"id":1046083,"introduction":"现在天气变得凉凉的了，你是否还光着脚丫呢，小心不要着凉了哟，毕竟寒从脚起，所以保暖脚丫是关键，小礼君保证你会爱上今天这篇攻略，通通都是我为你们选的少女款哟，而且还超级舒适的呢~不冻脚丫的秘诀就在这里，小礼君都入手了，你还不跟上吗？","label_ids":[],"liked":false,"likes_count":23058,"limit_end_at":null,"media_type":0,"published_at":1476608400,"share_msg":"现在天气变得凉凉的了，你是否还光着脚丫呢，小心不要着凉了哟，毕竟寒从脚起，所以保暖脚丫是关键，小礼君保证你会爱上今天这篇攻略，通通都是我为你们选的少女款哟，而且还超级舒适的呢~不冻脚丫的秘诀就在这里，小礼君都入手了，你还不跟上吗？","short_title":"","status":0,"template":"","title":"光脚丫的季节已经过去，护脚的事情交给它来做","updated_at":1476673180,"url":"http://www.liwushuo.com/posts/1046083"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1046049/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/161009/5il44zbkz.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/161009/5il44zbkz.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476349200,"editor_id":1018,"feature_list":[],"id":1046049,"introduction":"走进一间都是关于大自然的家里，打开门的那瞬间你所看到的都是自然之境时，那会有多舒服啊。尽管在外面遇到了多少的压力与不愉快，只要进了家里坏心情通通都烟消云散了。如果恰好你也喜欢这种自然风格，那么停下脚步来花几分钟来欣赏这些美物给你带来的好心情吧。","label_ids":[],"liked":false,"likes_count":9756,"limit_end_at":null,"published_at":1476328963,"share_msg":"走进一间都是关于大自然的家里，打开门的那瞬间你所看到的都是自然之境时，那会有多舒服啊。尽管在外面遇到了多少的压力与不愉快，只要进了家里坏心情通通都烟消云散了。如果恰好你也喜欢这种自然风格，那么停下脚步来花几分钟来欣赏这些美物给你带来的好心情吧。","short_title":"","status":0,"template":"","title":"回归\u201c大自然\u201d本色，还你一个清新自然的家","updated_at":1476328963,"url":"http://www.liwushuo.com/posts/1046049"},{"ad_monitors":[],"approved_at":null,"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045965/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/161008/40lswrpaw.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/161008/40lswrpaw.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1476176400,"editor_id":1191,"feature_list":[],"id":1045965,"introduction":"在干巴巴的秋冬季节，御寒保暖更要保湿。在相对封闭的空间里，无论是家庭还是公司，空气加湿器担当着营造舒适环境的重担。","label_ids":[],"liked":false,"likes_count":18961,"limit_end_at":null,"media_type":0,"published_at":1476176400,"share_msg":"在干巴巴的秋冬季节，御寒保暖更要保湿。在相对封闭的空间里，无论是家庭还是公司，空气加湿器担当着营造舒适环境的重担。","short_title":"","status":0,"template":"","title":"对抗干巴巴的秋冬季，你还需要一个强大的加湿器","updated_at":1476105384,"url":"http://www.liwushuo.com/posts/1045965"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045942/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/161008/ixy8kvvv6.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/161008/ixy8kvvv6.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1475917200,"editor_id":1191,"feature_list":[],"id":1045942,"introduction":"虽然小礼君已经离开校园数载，但作为一名文具控，收藏的文具们可一点儿都不比当学生的时候少，so，今天就来晒晒小礼君自己收藏的萌系文具，不知道有没有同道中人呢？现在的文具除了实用功能以外，还有一些超级治愈的萌物。?","label_ids":[],"liked":false,"likes_count":20982,"limit_end_at":null,"published_at":1475917200,"share_msg":"虽然小礼君已经离开校园数载，但作为一名文具控，收藏的文具们可一点儿都不比当学生的时候少，so，今天就来晒晒小礼君自己收藏的萌系文具，不知道有没有同道中人呢？现在的文具除了实用功能以外，还是超级治愈的萌物。?","short_title":"","status":0,"template":"","title":"可爱到犯规的文具们 (๑´ω`๑)","updated_at":1475916911,"url":"http://www.liwushuo.com/posts/1045942"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045892/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160928/pqeqmqarr.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160928/pqeqmqarr.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1475744400,"editor_id":1191,"feature_list":[],"id":1045892,"introduction":"冯唐说过， 我要用尽我的万种风情， 让你在将来任何不和我在一起的时候， 内心无法安宁。","label_ids":[],"liked":false,"likes_count":15494,"limit_end_at":null,"published_at":1475744400,"share_msg":"冯唐说过，","short_title":"","status":0,"template":"","title":"给留白的空间多一点想象","updated_at":1475325155,"url":"http://www.liwushuo.com/posts/1045892"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045880/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160928/gkc136q43.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160928/gkc136q43.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1475571600,"editor_id":1191,"feature_list":[],"id":1045880,"introduction":"吾日三省吾身：早饭吃啥，午饭吃啥，晚饭吃啥。","label_ids":[],"liked":false,"likes_count":18553,"limit_end_at":null,"published_at":1475571600,"share_msg":"吾日三省吾身：早饭吃啥，午饭吃啥，晚饭吃啥。","short_title":"","status":0,"template":"","title":"只有好看的便当盒，才能勾起我带饭的欲望","updated_at":1475326847,"url":"http://www.liwushuo.com/posts/1045880"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045864/content","cover_animated_webp_url":null,"cover_image_url":"http://img02.liwushuo.com/image/160928/cba2a35g2.jpg-w720","cover_webp_url":"http://img02.liwushuo.com/image/160928/cba2a35g2.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1475312400,"editor_id":1191,"feature_list":[],"id":1045864,"introduction":"你一定也遇到过这样的问题：一时冲动买买买，然后就再也没有用过的东西想着\u201c总有一天会用到\u201d，结果积了一整年的灰好不容易花时间收拾了，结果过几天又乱了。这样不停死循环的人生！怎么破？","label_ids":[],"liked":false,"likes_count":20556,"limit_end_at":null,"published_at":1475312400,"share_msg":"你一定也遇到过这样的问题：一时冲动买买买，然后就再也没有用过的东西想着\u201c总有一天会用到\u201d，结果积了一整年的灰好不容易花时间收拾了，结果过几天又乱了。这样不停死循环的人生！怎么破？","short_title":"","status":0,"template":"","title":"原谅我一生放荡不羁东西多，还好我是个收纳狂魔","updated_at":1475229585,"url":"http://www.liwushuo.com/posts/1045864"},{"ad_monitors":[],"author":{"avatar_url":"http://img03.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":2,"content_url":"http://www.liwushuo.com/posts/1045828/content","cover_animated_webp_url":null,"cover_image_url":"http://img03.liwushuo.com/image/160928/i897lm3ay.jpg-w720","cover_webp_url":"http://img03.liwushuo.com/image/160928/i897lm3ay.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1475139600,"editor_id":1191,"feature_list":[9],"id":1045828,"introduction":"无论是阳关充裕的沙滩，还是休闲惬意的午后，无论是温馨优雅的果园，还是神秘奇异的丛林，不管你的假日打算在哪里度过，小礼君都要教你如何在家假装度假，只需几件小物品，立马让你在家也能享受假日风情～?","label_ids":[],"liked":false,"likes_count":15680,"limit_end_at":null,"published_at":1475139600,"share_msg":"无论是阳关充裕的沙滩，还是休闲惬意的午后，无论是温馨优雅的果园，还是神秘奇异的丛林，不管你的假日打算在哪里度过，小礼君都要教你如何在家假装度假，只需几件小物品，立马让你在家也能享受假日风情～?","short_title":"","status":0,"template":"","title":"国庆不看人海，我有在家宅出假日风情的特殊技巧√","updated_at":1475062066,"url":"http://www.liwushuo.com/posts/1045828"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045794/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160927/sap4tzcix.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160927/sap4tzcix.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1474966800,"editor_id":1191,"feature_list":[],"id":1045794,"introduction":"\u201c若只是吃，可以像远古时代的人们那样把食物盛在叶片上吃。但若想达到更高层次，就有必要选择容器。食器与料理，永远有着无法分离的密切关系，两者的关系可说如同夫妻一般。\u201d\u2014\u2014北大路鲁山人在那篇著名《食器是料理的衣裳》中如此写道。","label_ids":[],"liked":false,"likes_count":20344,"limit_end_at":null,"published_at":1474966800,"share_msg":"\u201c若只是吃，可以像远古时代的人们那样把食物盛在叶片上吃。但若想达到更高层次，就有必要选择容器。食器与料理，永远有着无法分离的密切关系，两者的关系可说如同夫妻一般。\u201d\u2014\u2014北大路鲁山人在那篇著名《食器是料理的衣裳》中如此写道。","short_title":"","status":0,"template":"","title":"丢你一只下饭的碗，独享碗盏里的小确幸","updated_at":1475029290,"url":"http://www.liwushuo.com/posts/1045794"},{"ad_monitors":[],"author":{"avatar_url":"http://img02.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":2,"content_url":"http://www.liwushuo.com/posts/1045775/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160928/f4qow5eqs.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160928/f4qow5eqs.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1474707600,"editor_id":1191,"feature_list":[1,3,9],"id":1045775,"introduction":"最近的天气真是干得教人一天喝八杯水都觉得不够。为了让自己多喝一点水，只能换着法儿地泡不同的东西喝。 柠檬、菊花、铁观音喝了一圈已经不能再爱了，一到下午三四点就想点一杯下午茶喝喝，不知道乃们是不是也一样？","label_ids":[],"liked":false,"likes_count":21760,"limit_end_at":null,"published_at":1474707600,"share_msg":"最近的天气真是干得教人一天喝八杯水都觉得不够。为了让自己多喝一点水，只能换着法儿地泡不同的东西喝。 柠檬、菊花、铁观音喝了一圈已经不能再爱了，一到下午三四点就想点一杯下午茶喝喝，不知道乃们是不是也一样？","short_title":"","status":0,"template":"","title":"第64期｜秋风凛凛，你需要一杯体贴的热茶","updated_at":1475025393,"url":"http://www.liwushuo.com/posts/1045775"},{"ad_monitors":[],"author":{"avatar_url":"http://img01.liwushuo.com/image/160615/sd1vymm55.jpg","created_at":1465974337,"id":10,"introduction":"家居小物收集爱好者","nickname":"叫我小公举"},"content_type":1,"content_url":"http://www.liwushuo.com/posts/1045740/content","cover_animated_webp_url":null,"cover_image_url":"http://img01.liwushuo.com/image/160928/uxmswag0q.jpg-w720","cover_webp_url":"http://img01.liwushuo.com/image/160928/uxmswag0q.jpg?imageView2/2/w/720/q/85/format/webp","created_at":1474534800,"editor_id":1191,"feature_list":[],"id":1045740,"introduction":"每年的七夕或情人节，多数人都会选择和TA外出用餐，但是要浪漫，何仅限于这些被定义出来的节日呢？在家备上营造氛围的物品，什么时候是情人节，自己说了算。","label_ids":[],"liked":false,"likes_count":12446,"limit_end_at":null,"published_at":1474534800,"share_msg":"每年的七夕或情人节，多数人都会选择和TA外出用餐，但是要浪漫，何仅限于这些被定义出来的节日呢？在家备上营造氛围的物品，什么时候是情人节，自己说了算。","short_title":"","status":0,"template":"","title":"第63期｜在家准备两人餐都需要什么","updated_at":1475024986,"url":"http://www.liwushuo.com/posts/1045740"}]
     * share_url : http://hawaii.liwushuo.com/column/14
     * status : 0
     * subtitle :
     * title : 解忧杂货铺
     * updated_at : 1478254003
     */

    private DataBean data;
    private String message;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static class DataBean {
        private String banner_image_url;
        private String banner_webp_url;
        private String category;
        private String cover_image_url;
        private String cover_webp_url;
        private int created_at;
        private String description;
        private int id;
        private int likes_count;
        private int order;
        /**
         * next_url : http://api.liwushuo.com/v2/columns/14?limit=20&offset=20
         */

        private PagingBean paging;
        private int post_published_at;
        private String share_url;
        private int status;
        private String subtitle;
        private String title;
        private int updated_at;
        /**
         * ad_monitors : []
         * approved_at : 1477994916
         * author : {"avatar_url":"http://img01.liwushuo.com/image/160617/hzkkl1ohn.jpg","created_at":1465802857,"id":1,"introduction":"资深买买买达人","nickname":"小礼君"}
         * content_type : 1
         * content_url : http://www.liwushuo.com/posts/1046387/content
         * cover_animated_webp_url : null
         * cover_image_url : http://img02.liwushuo.com/image/161101/65x0un3ug.jpg-w720
         * cover_webp_url : http://img02.liwushuo.com/image/161101/65x0un3ug.jpg?imageView2/2/w/720/q/85/format/webp
         * created_at : 1478250000
         * editor_id : 1018
         * feature_list : []
         * id : 1046387
         * introduction : 老实说，实在是不喜欢冬天，因为真心太冷了。人都开始变懒了，虽然平时也不是很勤快吧，但是现在更加懒得动了，周末要是有朋友约的话，大概也只能拒绝了，我只想宅在家里，静静的，披着我的懒人毯子，然后开始冬眠。
         * label_ids : []
         * liked : false
         * likes_count : 11563
         * limit_end_at : null
         * media_type : 0
         * published_at : 1478250000
         * share_msg : 老实说，实在是不喜欢冬天，因为真心太冷了。人都开始变懒了，虽然平时也不是很勤快吧，但是现在更加懒得动了，周末要是有朋友约的话，大概也只能拒绝了，我只想宅在家里，静静的，披着我的懒人毯子，然后开始冬眠。
         * short_title :
         * status : 0
         * template :
         * title : 懒人冬眠时间开始了，毯子准备好了吗？
         * updated_at : 1478167445
         * url : http://www.liwushuo.com/posts/1046387
         */

        private List<PostsBean> posts;

        public String getBanner_image_url() {
            return banner_image_url;
        }

        public void setBanner_image_url(String banner_image_url) {
            this.banner_image_url = banner_image_url;
        }

        public String getBanner_webp_url() {
            return banner_webp_url;
        }

        public void setBanner_webp_url(String banner_webp_url) {
            this.banner_webp_url = banner_webp_url;
        }

        public String getCategory() {
            return category;
        }

        public void setCategory(String category) {
            this.category = category;
        }

        public String getCover_image_url() {
            return cover_image_url;
        }

        public void setCover_image_url(String cover_image_url) {
            this.cover_image_url = cover_image_url;
        }

        public String getCover_webp_url() {
            return cover_webp_url;
        }

        public void setCover_webp_url(String cover_webp_url) {
            this.cover_webp_url = cover_webp_url;
        }

        public int getCreated_at() {
            return created_at;
        }

        public void setCreated_at(int created_at) {
            this.created_at = created_at;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getLikes_count() {
            return likes_count;
        }

        public void setLikes_count(int likes_count) {
            this.likes_count = likes_count;
        }

        public int getOrder() {
            return order;
        }

        public void setOrder(int order) {
            this.order = order;
        }

        public PagingBean getPaging() {
            return paging;
        }

        public void setPaging(PagingBean paging) {
            this.paging = paging;
        }

        public int getPost_published_at() {
            return post_published_at;
        }

        public void setPost_published_at(int post_published_at) {
            this.post_published_at = post_published_at;
        }

        public String getShare_url() {
            return share_url;
        }

        public void setShare_url(String share_url) {
            this.share_url = share_url;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getSubtitle() {
            return subtitle;
        }

        public void setSubtitle(String subtitle) {
            this.subtitle = subtitle;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public int getUpdated_at() {
            return updated_at;
        }

        public void setUpdated_at(int updated_at) {
            this.updated_at = updated_at;
        }

        public List<PostsBean> getPosts() {
            return posts;
        }

        public void setPosts(List<PostsBean> posts) {
            this.posts = posts;
        }

        public static class PagingBean {
            private String next_url;

            public String getNext_url() {
                return next_url;
            }

            public void setNext_url(String next_url) {
                this.next_url = next_url;
            }
        }

        public static class PostsBean {
            private int approved_at;
            /**
             * avatar_url : http://img01.liwushuo.com/image/160617/hzkkl1ohn.jpg
             * created_at : 1465802857
             * id : 1
             * introduction : 资深买买买达人
             * nickname : 小礼君
             */

            private AuthorBean author;
            private int content_type;
            private String content_url;
            private Object cover_animated_webp_url;
            private String cover_image_url;
            private String cover_webp_url;
            private int created_at;
            private int editor_id;
            private int id;
            private String introduction;
            private boolean liked;
            private int likes_count;
            private Object limit_end_at;
            private int media_type;
            private int published_at;
            private String share_msg;
            private String short_title;
            private int status;
            private String template;
            private String title;
            private int updated_at;
            private String url;
            private List<?> ad_monitors;
            private List<?> feature_list;
            private List<?> label_ids;

            public int getApproved_at() {
                return approved_at;
            }

            public void setApproved_at(int approved_at) {
                this.approved_at = approved_at;
            }

            public AuthorBean getAuthor() {
                return author;
            }

            public void setAuthor(AuthorBean author) {
                this.author = author;
            }

            public int getContent_type() {
                return content_type;
            }

            public void setContent_type(int content_type) {
                this.content_type = content_type;
            }

            public String getContent_url() {
                return content_url;
            }

            public void setContent_url(String content_url) {
                this.content_url = content_url;
            }

            public Object getCover_animated_webp_url() {
                return cover_animated_webp_url;
            }

            public void setCover_animated_webp_url(Object cover_animated_webp_url) {
                this.cover_animated_webp_url = cover_animated_webp_url;
            }

            public String getCover_image_url() {
                return cover_image_url;
            }

            public void setCover_image_url(String cover_image_url) {
                this.cover_image_url = cover_image_url;
            }

            public String getCover_webp_url() {
                return cover_webp_url;
            }

            public void setCover_webp_url(String cover_webp_url) {
                this.cover_webp_url = cover_webp_url;
            }

            public int getCreated_at() {
                return created_at;
            }

            public void setCreated_at(int created_at) {
                this.created_at = created_at;
            }

            public int getEditor_id() {
                return editor_id;
            }

            public void setEditor_id(int editor_id) {
                this.editor_id = editor_id;
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getIntroduction() {
                return introduction;
            }

            public void setIntroduction(String introduction) {
                this.introduction = introduction;
            }

            public boolean isLiked() {
                return liked;
            }

            public void setLiked(boolean liked) {
                this.liked = liked;
            }

            public int getLikes_count() {
                return likes_count;
            }

            public void setLikes_count(int likes_count) {
                this.likes_count = likes_count;
            }

            public Object getLimit_end_at() {
                return limit_end_at;
            }

            public void setLimit_end_at(Object limit_end_at) {
                this.limit_end_at = limit_end_at;
            }

            public int getMedia_type() {
                return media_type;
            }

            public void setMedia_type(int media_type) {
                this.media_type = media_type;
            }

            public int getPublished_at() {
                return published_at;
            }

            public void setPublished_at(int published_at) {
                this.published_at = published_at;
            }

            public String getShare_msg() {
                return share_msg;
            }

            public void setShare_msg(String share_msg) {
                this.share_msg = share_msg;
            }

            public String getShort_title() {
                return short_title;
            }

            public void setShort_title(String short_title) {
                this.short_title = short_title;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String getTemplate() {
                return template;
            }

            public void setTemplate(String template) {
                this.template = template;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public int getUpdated_at() {
                return updated_at;
            }

            public void setUpdated_at(int updated_at) {
                this.updated_at = updated_at;
            }

            public String getUrl() {
                return url;
            }

            public void setUrl(String url) {
                this.url = url;
            }

            public List<?> getAd_monitors() {
                return ad_monitors;
            }

            public void setAd_monitors(List<?> ad_monitors) {
                this.ad_monitors = ad_monitors;
            }

            public List<?> getFeature_list() {
                return feature_list;
            }

            public void setFeature_list(List<?> feature_list) {
                this.feature_list = feature_list;
            }

            public List<?> getLabel_ids() {
                return label_ids;
            }

            public void setLabel_ids(List<?> label_ids) {
                this.label_ids = label_ids;
            }

            public static class AuthorBean {
                private String avatar_url;
                private int created_at;
                private int id;
                private String introduction;
                private String nickname;

                public String getAvatar_url() {
                    return avatar_url;
                }

                public void setAvatar_url(String avatar_url) {
                    this.avatar_url = avatar_url;
                }

                public int getCreated_at() {
                    return created_at;
                }

                public void setCreated_at(int created_at) {
                    this.created_at = created_at;
                }

                public int getId() {
                    return id;
                }

                public void setId(int id) {
                    this.id = id;
                }

                public String getIntroduction() {
                    return introduction;
                }

                public void setIntroduction(String introduction) {
                    this.introduction = introduction;
                }

                public String getNickname() {
                    return nickname;
                }

                public void setNickname(String nickname) {
                    this.nickname = nickname;
                }
            }
        }
    }
}
